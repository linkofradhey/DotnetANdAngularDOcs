﻿using System;


namespace BasicsOfCSharp
{
    internal class VarDemo
    {
        static void Main()
        {
            #region Var Demo
            //var v1; //var must init.
            dynamic d; //dynamic can be init with null
            var intVar = 20;
            //intVar = "sdfdff"; //can not assigned different value other than number
            var strVar = "welcome";
            var doubleVar = 34.5;
            var chVar = 'a';
            var boolVar = true;
            int[] nums = {22,33,44,67,78 };
            var v = nums;
            Console.WriteLine($"integer={intVar}\nstring={strVar}\ndouble={doubleVar}\nchar={chVar}\nbool={boolVar}");
            Console.WriteLine(intVar.GetType());
            #endregion

            #region foreach demo
            foreach (var item in v)
            {
                Console.Write($"{item}\t");
            }
            #endregion
        }

        #region static functions
        static dynamic Function1()
        {
            return "message";
        }

        static string Function2()
        {
            return "hello world";
        }
        #endregion
    }
}
