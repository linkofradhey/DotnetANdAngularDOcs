﻿using System;


namespace BasicsOfCSharp
{
    internal class ObjectTypeDemo
    {
         static void Main()
        {
            object intObj = 20;
            object doubleObj = 34.6;
            object strObj = "hello";
            object chObj = 'a';
            object boolObj = true;

            Console.WriteLine($"integer={intObj}\n double={doubleObj}\n string={strObj}\n bool={boolObj}");

        }
    }
}
