﻿using System;


namespace BasicsOfCSharp
{
    internal class AsOperatorDemo
    {
        static void Main()
        {
            object[] strObj = { "str1","str2","str3","str4"};
            string str = strObj[1] as string  ;
          Console.WriteLine(str);

        }
    }
}
