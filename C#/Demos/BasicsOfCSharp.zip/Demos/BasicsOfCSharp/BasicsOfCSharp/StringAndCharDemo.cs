﻿using System;


namespace BasicsOfCSharp
{
    internal class StringAndCharDemo
    {
        static void Main()
        {
            string message = "good morning";
            char c= 'a';
            string message1 = c.ToString();

            Console.WriteLine($"message={message}\t char={message1}");
        }
    }
}
