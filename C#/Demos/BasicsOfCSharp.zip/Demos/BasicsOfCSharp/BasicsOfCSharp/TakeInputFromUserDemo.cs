﻿using System;


namespace BasicsOfCSharp
{
    internal class TakeInputFromUserDemo
    {
        static void Main()
        {
            Console.Write("Please enter a Product Price:");
            
            double proAmount =Convert.ToDouble( Console.ReadLine());

            Console.Write("Please enter GST Per:");
            double per=Convert.ToDouble( Console.ReadLine());

            var gstAmount = proAmount / 100 * per;
            Console.WriteLine($"GST Amount={gstAmount}\nTotal Amount={proAmount+gstAmount}");
        }
    }
}
