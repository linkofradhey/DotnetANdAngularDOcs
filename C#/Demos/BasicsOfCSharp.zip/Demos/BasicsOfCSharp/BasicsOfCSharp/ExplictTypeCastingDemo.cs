﻿using System;
using System.Collections.Generic;


namespace BasicsOfCSharp
{
    internal class ExplictTypeCastingDemo
    {
        static void Main()
        {
            double d = 34.6;
            int num =(int) d;
            Console.WriteLine($"after converting double into an integer using syntax, The value of num={num}");

            int num1 = Convert.ToInt32(d);
            Console.WriteLine($"after converting double into an int using convert class,  value of num1 ={num1}");
        }
    }
}
