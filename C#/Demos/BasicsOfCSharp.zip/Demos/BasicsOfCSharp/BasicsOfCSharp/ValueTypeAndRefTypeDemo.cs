﻿using System;


namespace BasicsOfCSharp
{
    internal class ValueTypeAndRefTypeDemo
    {
        static void Main()
        {
            int a = 30; //a is a value type. stack name is a, which has value 30
       
            Console.WriteLine(a);

            Class1 c1 = new Class1(); //c1 is a ref. type which has references of num and ch
            Console.WriteLine(c1.num);
            Console.WriteLine(c1.ch);

        }
    }

    class Class1
    {
       public int num = 20; //num is a value type
       public char ch= 'A';
    }
}
