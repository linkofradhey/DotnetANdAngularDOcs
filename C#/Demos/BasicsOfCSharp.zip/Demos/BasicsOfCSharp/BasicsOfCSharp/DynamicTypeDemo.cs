﻿using System;


namespace BasicsOfCSharp
{
    internal class DynamicTypeDemo
    {
        static void Main()
        {
            int num = 20; //stack allocation for this will be at compile-time
            dynamic intDyn = 20; //memory headp will be allocated at runtime
            dynamic strDyn = "welcome";
            dynamic chDyn = 'A';
            dynamic boolDyn = true;
            dynamic nullDyn= null; ;

           
            Console.WriteLine($"integer={intDyn}\nstring={strDyn}\ncharacter={chDyn}\nbool={boolDyn}\nnull={nullDyn}");
            
            Console.WriteLine($"intDyn={intDyn.GetType()}\nstrDyn={strDyn.GetType()}\nchDyn={chDyn.GetType()}\n boolDyn={boolDyn.GetType()}");

            Console.WriteLine($"managed type of int={typeof(int)}");
        }
    }
}
