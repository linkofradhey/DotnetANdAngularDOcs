﻿using System;


namespace BasicsOfCSharp
{
    internal class ImpliciteTypeCastingDemo
    {
        static void Main()
        {
            int num = 20;
            double d = num;//implicit type casting
            Console.WriteLine($"value of d={d}");
        }
    }
}
