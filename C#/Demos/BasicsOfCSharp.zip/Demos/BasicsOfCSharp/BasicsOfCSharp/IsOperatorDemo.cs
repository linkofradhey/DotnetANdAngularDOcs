﻿using System;
using System.ComponentModel;


namespace BasicsOfCSharp
{
    internal class IsOperatorDemo
    {
        static void Main()
        {
            //1.Type compatibility

            Animal animal1=new Animal();
           var isAllAnimalTiger = animal1 is Tiger; //all animals are tiger
            Console.WriteLine($"is all animal are tiger?={isAllAnimalTiger}");

            Tiger tiger1 = new Tiger();
            var isAllTigerAnimal = tiger1 is Animal;
            Console.WriteLine($"is all tigers are animal?={isAllTigerAnimal}"); //all tigers are animal

            //2.relational pattern matching
            var century = 100;
            if (century is 100) //its better than ==
            {
                Console.WriteLine("Its century");
            }

            var age = 20;
            if (age is > 18)
            {
                Console.WriteLine("Its a major person");
            }

            //3.null refernce checking
            string name = null;
            if(name is null)
            {
                name = "default";
            }
            Console.WriteLine(name);

            //4.array pettern matching
            int[] nums = { 1,2,3};
            if(nums is [1, 2, 3])
            {
                Console.WriteLine($"array contains 1,2,3");
            }
        }

    }

    class Animal { }
    
    class Tiger:Animal { }
}
