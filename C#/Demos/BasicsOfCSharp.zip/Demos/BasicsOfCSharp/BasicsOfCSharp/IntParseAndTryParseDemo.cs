﻿using System;


namespace BasicsOfCSharp
{
    internal class IntParseAndTryParseDemo
    {
        static void Main()
        {
          
            //int.parse
            //string value = "10065645645546456456";
            //int num=int.Parse(value);
            //Console.WriteLine($"after converting string value to an int using int.parse={num}");

            string value = "10076878678768678678678";
            int result;
           var isConvertible= int.TryParse(value, out result);

            if (isConvertible){
               
                Console.WriteLine($"The number of value after converting using int.TryParse={result}");
            }
            else
            {
                Console.WriteLine("Invalid value");
            }

        }
    }
}
