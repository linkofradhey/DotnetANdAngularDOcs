﻿using System;


namespace BasicsOfCSharp
{
    internal class ReadOnlyDemo
    {
        readonly double GstPer;

        public ReadOnlyDemo()
        {
            GstPer = 18;
        }

        static void Main()
        {
            ReadOnlyDemo readOnlyDemo = new ReadOnlyDemo();
            var proAmount = 100;
            var gstAmount = proAmount / 100 * readOnlyDemo.GstPer;
            var totalAmount = proAmount + gstAmount;
            Console.WriteLine($"GST Amount={gstAmount} and Total Amount={totalAmount}");

        }
    }
}
