﻿using System;


namespace BasicsOfCSharp
{
    internal class ConstDemo
    {
        static void Main()
        {
            const double GSTPER = 18; //const must be init. but it can not be assigned
            //GSTPER = 28; //const can not be assigned

            var proAmount = 1000;
            var gstAmount = proAmount / 100 * GSTPER;
            var totalAmount=gstAmount+proAmount;
            Console.WriteLine($"GST Amount={gstAmount}\t Total Product Amount={totalAmount}");

        }
    }
}
