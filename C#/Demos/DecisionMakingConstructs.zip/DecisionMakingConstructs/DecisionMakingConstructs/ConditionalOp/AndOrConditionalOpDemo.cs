﻿using System;


namespace DecisionMakingConstructs.ConditionalOp
{
    internal class AndOrConditionalOpDemo
    {
        static void Main()
        {
            Console.Write("Enter Your Highest Qualification:(UG/PG/Degree):");
            string qualification = Console.ReadLine().ToUpperInvariant();

            Console.Write("Enter Your experience in Months:");
            short experience = Convert.ToInt16(Console.ReadLine());

            //if(qualification is "PG" && experience is > 12)
            if (qualification is "PG" || experience is > 12)
            {
                Console.WriteLine("Congratulations, You are eligible for an interview");
            }
            else
            {
                Console.WriteLine("You are NOT eligible for an interview");
            }
        }
    }
}
