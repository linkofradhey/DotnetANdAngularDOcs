﻿using System;


namespace DecisionMakingConstructs.Jumping
{
    internal class SwitchCaseDemo
    {
        static void Main()
        {
            Console.Write("Enter an Item (food,service,ornments):");
            string item = Console.ReadLine();
            item = item.ToLowerInvariant();

            Console.Write("Enter an Amount for Product/Service:");
            double amount = Convert.ToDouble(Console.ReadLine());

            double totalAmount = 0;
            double gstAmount = 0;
            double gstPer = 0;
            switch (item)
            {
                case "food":
                            gstPer = 1;
                            gstAmount = amount / 100 * gstPer;
                            break;
                case "service":
                            gstPer = 8;
                            gstAmount= amount / 100 * gstPer;
                            break;
                case "ornments":
                            gstPer = 3;
                            gstAmount = amount / 100 * gstPer;
                            break;
                default:
                            Console.WriteLine("Invalid Item Name");
                            break;
            }

            totalAmount = gstAmount + amount;
            Console.WriteLine($"GST Amount={gstAmount} and Total Amount={totalAmount}");
        }
    }
}
