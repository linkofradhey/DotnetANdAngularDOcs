﻿using System;


namespace DecisionMakingConstructs.TernaryOp
{
    internal class TernaryOpDemo
    {
        static void Main()
        {
            Console.Write("Please Enter your Annual Income in Rupees:");
            double annualIncome = Convert.ToDouble(Console.ReadLine());

          var result=  annualIncome is > 500000 ? Message1() : Message2();
            Console.WriteLine(result);
        }

        static string Message1()
        {
            //your complex/large logic goes here
            return "You are liable to pay I.T.";
        }
        static string Message2()
        {
            //your complex/large logic goes here
            return "You are NOT liable to pay I.T.";
        }
    }
}
