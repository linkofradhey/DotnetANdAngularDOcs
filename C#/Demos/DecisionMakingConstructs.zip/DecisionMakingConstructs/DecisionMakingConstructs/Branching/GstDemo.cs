﻿using System;


namespace DecisionMakingConstructs.Branching
{
    internal class GstDemo
    {
        static void Main()
        {
            Console.Write("Enter an Item (food,service,ornments):");
            string item=Console.ReadLine();
            item = item.ToLowerInvariant();

            Console.Write("Enter an Amount for Product/Service:");
            double amount = Convert.ToDouble(Console.ReadLine());

            double totalAmount = 0;
            double gstAmount = 0;

            if (item is "food")
            {
                double gstPer = 1;
                gstAmount = amount / 100 * gstPer;
            }
            else if(item is "service")
            {
                double gstPer = 8;
                gstAmount=amount / 100 * gstPer;
            }
            else if(item is "ornments")
            {
                double gstPer = 3;
                gstAmount = amount / 100 * gstPer;
            }
            else
            {
                Console.WriteLine("Invalid Item Name");
            }
            totalAmount = gstAmount + amount;
            Console.WriteLine($"GST Amount={gstAmount} and Total Amount={totalAmount}");
        }
    }
}
