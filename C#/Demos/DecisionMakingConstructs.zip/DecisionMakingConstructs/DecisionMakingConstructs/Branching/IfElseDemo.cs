﻿using System;


namespace DecisionMakingConstructs.Branching
{
    internal class IfElseDemo
    {
        static void Main()
        {
            Console.Write("Please Enter your Annual Income in Rupees:");
            double annualIncome =Convert.ToDouble( Console.ReadLine());

            if (annualIncome >= 500000)
            {
                Console.WriteLine("You are liable to pay I.T.");
            }
            else
            {
                Console.WriteLine("You are NOT liable to pay I.T.");
            }

        }
    }
}
