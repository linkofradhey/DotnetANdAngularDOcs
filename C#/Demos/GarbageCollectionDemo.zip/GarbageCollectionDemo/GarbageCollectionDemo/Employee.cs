﻿using System;
using System.Collections.Generic;
using System.Globalization;


namespace GarbageCollectionDemo
{
    internal class Employee:IDisposable
    {
        public int EmpCode { get; set; }
        public string  EmpName { get;set; }

        public void Dispose()
        {
           
            GC.SuppressFinalize(this);
        }
    }

    class PartTimeEmployee : Employee
    {

    }
}
