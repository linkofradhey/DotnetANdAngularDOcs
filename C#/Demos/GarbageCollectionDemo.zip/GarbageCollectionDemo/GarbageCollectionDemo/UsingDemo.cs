﻿using System;
using System.Collections.Generic;


namespace GarbageCollectionDemo
{
    internal class UsingDemo
    {
        static void Main()
        {
            using (Employee employee1 = new Employee { EmpCode = 100, EmpName = "scott" })
            {
                Console.WriteLine($"{employee1.EmpCode}\t{employee1.EmpName}");
            }

            Employee employee2 = new Employee { EmpCode = 100, EmpName = "scott" };

            using (PartTimeEmployee employee3 = new PartTimeEmployee { EmpCode = 101, EmpName = "tiger" })
            {
                Console.WriteLine($"{employee3.EmpCode}\t{employee3.EmpName}");
            }
        }
    }
}
