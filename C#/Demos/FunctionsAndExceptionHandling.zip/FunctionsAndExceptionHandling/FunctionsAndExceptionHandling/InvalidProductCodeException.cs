﻿using System;


namespace FunctionsAndExceptionHandling
{
    //1.Create a Derieved class by inheriting Exception base class
    internal class InvalidProductCodeException:Exception
    {
        //inheriting constructor of base classs
        public InvalidProductCodeException():base("Invalid Product Code")
        {
            
        }
    }

    //2.Validate Product code and throw an exception
    class Product
    {
        public int ProductCode { get; set; }
        public string ProductName { get; set; }

        public void ValidateProductCode()
        {
            if (this.ProductCode <= 0)
            {
                throw new InvalidProductCodeException();
            }
        }
    }
}
