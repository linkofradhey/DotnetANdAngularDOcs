﻿using System;


namespace FunctionsAndExceptionHandling
{
    internal class OptionalParamDemo
    {
        static void Main()
        {
            MathUtility mathUtility = new MathUtility();
            var size=  mathUtility.Size(20);
            Console.WriteLine($"Size of box is:{size}");

          var result=  mathUtility.Details(100, "Scott", city:"Mumbai");
            Console.WriteLine(result);
        }
    }
}
