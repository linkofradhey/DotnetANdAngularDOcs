﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunctionsAndExceptionHandling
{
    internal class ReturnObjectDemo
    {
        static void Main()
        {
            Employee emp1 = new Employee();
           var emp= emp1.Details(100, "scott", "scott@gmail.com");
            Console.WriteLine($"{emp.EmpCode}\t{emp.EmpName}\t{emp.Email}");
        }
    }
}
