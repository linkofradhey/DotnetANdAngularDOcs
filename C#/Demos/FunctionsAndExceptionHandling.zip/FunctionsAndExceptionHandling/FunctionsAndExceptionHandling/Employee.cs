﻿using System;

namespace FunctionsAndExceptionHandling
{
    internal class Employee
    {
        public int EmpCode { get; set; }
        public string EmpName { get; set; }
        public string Email { get; set; }


        public Employee Details(int code,string name,string email)
        {
            return new Employee {EmpCode=code,EmpName=name,Email=email};
        }
    }
}
