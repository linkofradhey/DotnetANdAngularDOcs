﻿using System;


namespace FunctionsAndExceptionHandling
{
    internal class ParamKeywordDemo
    {
        static void Main()
        {
            MathUtility mathUtility = new MathUtility();
            
            mathUtility.PrintMarks(56, 67, 45, 56, 34, 78);
        }
    }
}
