﻿using System;


namespace FunctionsAndExceptionHandling
{
    internal class ByValAndByRefDemo
    {
        static void Main()
        {
            MathUtility mathUtility = new MathUtility();
            int a = 99;
           var result1= mathUtility.Increment(a);
            Console.WriteLine($"Value returned by funciton is {result1} value of local variable is {a}");

            int b = 99;
            var result2= mathUtility.Increment(ref b);
            Console.WriteLine($"Value returned by funciton is {result2} value of local variable is {b}");

        }
    }
}
