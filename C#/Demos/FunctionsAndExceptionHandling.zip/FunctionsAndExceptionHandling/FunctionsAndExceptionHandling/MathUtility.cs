﻿using System;


namespace FunctionsAndExceptionHandling
{
    internal class MathUtility
    {
       public  void Add()
        {
            int a = 10, b = 30;
            int c= a + b;
            Console.WriteLine($"Sum of {a} and {b} is {c}");
        }

        public int Add(int a,int b)
        {
            return a + b;
        }

        public int Increment(int x) //x is a byval param.
        {
            x++;
            return x;
        }
        
        public int Increment(ref int x) // x is a byref param.
        {
            x++;
            return x;
        }

        public double GstCalculation(double proAmount,double per,out double gstAmount )
        {
            gstAmount = proAmount / 100 * per; //out param must be assigned
            var total = proAmount + gstAmount;
            return total;
        }

        public double Size(double width,double height = 10)
        {
            return width * height;
        }

        public string Details(int code, string name, string state="MH", string city = "Pune")
        {
            return $"{code}\t{name}\t{state}\t{city}";
        }

        public void PrintMarks(params int[] marks)
        {
            foreach (var item in marks)
            {
                Console.Write($"{item}\t");
            }
        }

        public int Factorial(int n)
        {
            //Base Case: factorial of 0 or 1 is 1
            if(n==0 || n == 1)
            {
                return 1;
            }
            else
            {
                //recursive call: factorial of n is n multiplied by factorial of (n-1)
                var result = n * Factorial(n - 1);
                return result;
            }
        }

        public double CalcProduct(int n)=>n * n;
        
    }
}
