﻿using System;


namespace FunctionsAndExceptionHandling
{
    internal class Program
    {
        static void Main()
        {
            MathUtility mathUtility = new MathUtility();
            mathUtility.Add();

            int x = 12;
            int y = 30;
           var result= mathUtility.Add(x, y);
            Console.WriteLine($"The sum of {x} and {y} is {result}");
        }
    }
}
