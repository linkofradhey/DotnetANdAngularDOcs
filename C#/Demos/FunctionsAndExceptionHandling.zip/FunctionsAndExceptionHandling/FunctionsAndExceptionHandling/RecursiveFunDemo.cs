﻿using System;


namespace FunctionsAndExceptionHandling
{
    internal class RecursiveFunDemo
    {
        static void Main()
        {
            MathUtility mathUtility = new MathUtility();
            var num = 5;
            var result = mathUtility.Factorial(num);
            Console.WriteLine(result);

            //Message1();
        }

        public static void Message1()
        {
            Message2();
            Console.WriteLine("Message1()");
        }
        public static void Message2()
        {
            Message3();
            Console.WriteLine("Message2()");
        }
        public static void Message3()
        {

            Console.WriteLine( "Message3()");
        }


    }
}
