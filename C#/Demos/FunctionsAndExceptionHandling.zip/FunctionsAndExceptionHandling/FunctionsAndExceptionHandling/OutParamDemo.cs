﻿using System;
using System.ComponentModel.Design;


namespace FunctionsAndExceptionHandling
{
    internal class OutParamDemo
    {
        static void Main()
        {
            MathUtility mathUtility = new MathUtility();
            double proAmount = 1000;
            double per = 18;
            double gstAmount;
          var totalAmount=  mathUtility.GstCalculation(proAmount, per, out gstAmount);
            Console.WriteLine($"GST Amount:{gstAmount} and Total Amount:{totalAmount}");
        }
    }
}
