﻿using System;


namespace FunctionsAndExceptionHandling
{
    internal class CustomExceptDemo
    {
        static void Main()
        {
            //3.to catch exception using custom exception class
            try
            {
                Product product1 = new Product { ProductCode = 0, ProductName = "Soap" };
                product1.ValidateProductCode();
            }catch(InvalidProductCodeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
