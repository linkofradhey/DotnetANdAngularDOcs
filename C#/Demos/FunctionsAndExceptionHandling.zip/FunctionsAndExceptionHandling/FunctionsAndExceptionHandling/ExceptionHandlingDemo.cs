﻿using System;
using System.Reflection.Metadata;


namespace FunctionsAndExceptionHandling
{
    internal class ExceptionHandlingDemo
    {
        static void Main()
        {
            try
            {
                Console.Write("Enter your Age:");
                short age = Convert.ToInt16(Console.ReadLine());
                if (age >= 18)
                {
                    Console.WriteLine("You are a major person");
                }
                else
                {
                    Console.WriteLine("You are a minor person");
                }
            }   
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(OverflowException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                //closes the database connection
                //collect GC forcefuly
                GC.Collect();
                Console.WriteLine("i'm in finally");
            }
           
            
        }
    }
}
