﻿using System;


namespace ThreadingAndTask
{
    internal class TaskDemo3
    {
        static void Main()
        {
            var tResult = Task<int>.Run(() => PrintSum());
            Console.WriteLine(tResult.Result);

            var tResult2 = Task<Employee>.Run(() =>
            {
                var employees = new List<Employee> 
                {
                    new Employee{EmpCode=100,EmpName="Scott"},
                    new Employee{EmpCode=101,EmpName="Tiger"}

                };
                return employees;
            });

            foreach (var employee in tResult2.Result)
            {
                Console.WriteLine($"{employee.EmpCode}\t{employee.EmpName}");
            }
        }

        public static int PrintSum()
        {
            int sum = 0;
            for (int i = 1; i <=15 ; i++)
            {
                sum = sum + i;
                Console.WriteLine(sum);
            }

            return sum;
        }
    }
}
