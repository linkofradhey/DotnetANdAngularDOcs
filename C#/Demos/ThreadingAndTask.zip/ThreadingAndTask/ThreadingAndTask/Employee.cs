﻿using System;


namespace ThreadingAndTask
{
    internal class Employee
    {
        public int EmpCode { get; set; }

        public string EmpName { get; set; }
    }
}
