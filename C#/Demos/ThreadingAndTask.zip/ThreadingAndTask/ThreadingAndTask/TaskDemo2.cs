﻿using System;


namespace ThreadingAndTask
{
    internal class TaskDemo2
    {
        static void Main()
        {
            //To start a task immediately
            Task task1 = Task.Run(ToDo1);
            Task task2= Task.Run(ToDo2);

            //To pass anonymous function to task
            Task task3 = Task.Run(() =>
            {
                Console.WriteLine("Hello world");
            });
          

            Console.ReadLine();
        }

        public static void ToDo1()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Thread  ID:{Thread.CurrentThread.ManagedThreadId} and i={i}");
                Thread.Sleep(2000);
            }
        }

        public static void ToDo2()
        {
            for (int i = 21; i < 30; i++)
            {
                Console.WriteLine($"Thread  ID:{Thread.CurrentThread.ManagedThreadId} and i={i}");
                Thread.Sleep(2000);
            }
        }
    }
}
