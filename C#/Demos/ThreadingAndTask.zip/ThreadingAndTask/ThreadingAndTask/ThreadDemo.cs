﻿using System;
using System.Collections.Generic;


namespace ThreadingAndTask
{
    internal class ThreadDemo
    {
        static void Main()
        {
            Thread thread1 = new Thread(ToDo1);
            thread1.Start();

            thread1.Join(); //to execute thread in sync.
            Thread thread2=new Thread(ToDo2);
            thread2.Start();
        }

        public static void ToDo1()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Thread  ID:{Thread.CurrentThread.ManagedThreadId} and i={i}");
                Thread.Sleep(2000);
            }
        }

        public static void ToDo2()
        {
            for (int i = 21; i < 30; i++)
            {
                Console.WriteLine($"Thread  ID:{Thread.CurrentThread.ManagedThreadId} and i={i}");
                Thread.Sleep(2000);
            }
        }
    }
}
