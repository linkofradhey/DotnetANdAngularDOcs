﻿using System;


namespace ThreadingAndTask
{
    internal class TaskDemo1
    {
        static void Main()
        {
            Task task1 = new Task(ToDo1);
            task1.Start();
            
            Task task2 = new Task(ToDo2);
            task2.Start();

            Console.ReadLine();

        }
        public static void ToDo1()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine($"Thread  ID:{Thread.CurrentThread.ManagedThreadId} and i={i}");
                Thread.Sleep(2000);
            }
        }

        public static void ToDo2()
        {
            for (int i = 21; i < 30; i++)
            {
                Console.WriteLine($"Thread  ID:{Thread.CurrentThread.ManagedThreadId} and i={i}");
                Thread.Sleep(2000);
            }
        }

    }
}
