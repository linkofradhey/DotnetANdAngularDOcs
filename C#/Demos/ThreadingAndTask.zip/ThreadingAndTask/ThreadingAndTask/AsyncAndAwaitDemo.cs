﻿using System;
using System.IO;

namespace ThreadingAndTask
{
    internal class AsyncAndAwaitDemo
    {
        static  async Task Main()
        {
          await  WriteData1();
          await WriteData2();
        }

        public static async Task WriteData1()
        {
            Console.WriteLine("Async Method1 Started....");
            string[] values = {"Good Morning","Good afternoon","Good evenning" };
            await File.AppendAllLinesAsync("myfile1.txt",values);
            Console.WriteLine("Async Method1 completed. ");

        }

        public static async Task WriteData2()
        {
            Console.WriteLine("Async Method2 Started....");
            string[] values = { "Good Morning", "Good afternoon", "Good evenning" };
            await File.AppendAllLinesAsync("myfile2.txt", values);
            Console.WriteLine("Async Method2 completed. ");

        }
    }


}
