﻿using System;
using GstLib;

namespace UseGstLib
{
    internal class GstCalculationDemo
    {
       static void Main()
        {
            Gst gst1 = new Gst(2000, 18);
           var gstAmount= gst1.CalculateGstAmount();
            Console.WriteLine($"GST Amount is:{gstAmount} and Total Amount is:{gst1.Totalamount}");

           var gstCompositionAmount= gst1.CalculateGstComposition();
            Console.WriteLine($"GST Composition Amount is:{gstCompositionAmount} and Total Amount is:{gst1.Totalamount}");
        }
    }
}
