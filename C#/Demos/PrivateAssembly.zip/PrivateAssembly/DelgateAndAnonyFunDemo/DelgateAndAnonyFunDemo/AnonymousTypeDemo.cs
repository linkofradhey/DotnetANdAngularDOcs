﻿using System;
using System.Collections.Generic;


namespace DelgateAndAnonyFunDemo
{
    internal class AnonymousTypeDemo
    {
        static void Main()
        {
            var std = new { RollNo = 100, Name = "Scott", Email = "scott@gmail.com" };
           // std.RollNo = 101; //read-only
           Console.WriteLine($"{std.RollNo}\t{std.Name}\t{std.Email}");

            var students = new[]
            {
                new { RollNo = 100, Name = "Scott", Email = "scott@gmail.com" },
                new { RollNo = 101, Name = "Tiger", Email = "tiger@gmail.com" },
                new { RollNo = 100, Name = "Smith", Email = "smith@gmail.com" }
            };

            foreach (var item in students)
            {
                Console.WriteLine($"{item.RollNo}\t{item.Name}\t{item.Email}");
            }
        }
    }
}
