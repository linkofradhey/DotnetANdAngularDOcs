﻿using System;
using System.Collections.Generic;


namespace DelgateAndAnonyFunDemo
{
    internal class LambdaExpressionDemo
    {
        static void Main()
        {
            //anonymous function using predicate
            Predicate<string> predicate1 = (str) =>
            {
                if (str.Length >= 10)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            };

           var result= predicate1("hello world");
            Console.WriteLine(result);

            //anonymous function using action
            Action<int, int> action1 = (num1, num2) => Console.WriteLine($"Result from action={num1+num2}");
            action1(20, 50);

            //anonymous function using func
            Func<int,int,int> func1= (num1, num2) =>num1 + num2;
           var result2= func1(40, 60);
            Console.WriteLine($"Result from func={result2}");
        }
    }
}
