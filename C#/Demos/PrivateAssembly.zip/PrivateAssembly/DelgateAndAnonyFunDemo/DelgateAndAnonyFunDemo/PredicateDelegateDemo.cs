﻿using System;
using System.Collections.Generic;


namespace DelgateAndAnonyFunDemo
{
    internal class PredicateDelegateDemo
    {
        public static bool ValidateStringLength(string input)
        {
            return input.Length > 10;
        }
        static void Main()
        {
            Predicate<string> predicate = ValidateStringLength;
           var result= predicate("hello world");
            Console.WriteLine(result?"String is valid":"String is NOT valid");
        }
    }
}
