﻿using System;
using System.Drawing;


namespace DelgateAndAnonyFunDemo
{
    internal class CustomDelegateDemo
    {
        // declare delegate
        public delegate void Print(int value);
        static void Main(string[] args)
        {
            // Print delegate points to PrintD
            Print printDel = PrintID;
            // or
            // Print printDel= new Print(PrintID);

            printDel(10);
            
            // Print delegate points to PrintSalary
            printDel += PrintSalary;
            printDel(11);
           

        }
        public static void PrintID(int num)
        {
            Console.WriteLine($"Your ID is: {num}");
        }
        public static void PrintSalary(int amount)
        {
            Console.WriteLine($"Your Salary is: {amount}" );
        }
    }
}

