﻿using System;
using System.Collections.Generic;


namespace DelgateAndAnonyFunDemo
{
    internal class ActionDelegateDemo
    {
        public static void Add(int num1, int num2)
        {
            Console.WriteLine(num1 + num2);
        }
        static void Main()
        {
            Action<int, int> action = Add;
            action(10, 20);
        }
    }
}
