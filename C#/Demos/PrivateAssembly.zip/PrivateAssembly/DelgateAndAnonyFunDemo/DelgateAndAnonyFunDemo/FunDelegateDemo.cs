﻿using System;
using System.Collections.Generic;


namespace DelgateAndAnonyFunDemo
{
    internal class FunDelegateDemo
    {
        public static int Add(int num1, int num2)
        {
            return (num1 + num2);
        }
        static void Main()
        {
            Func<int, int, int> func = Add;
           var result= func(10, 30);
            Console.WriteLine(result);
        }
    }
}
