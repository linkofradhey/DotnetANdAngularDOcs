﻿namespace GstLib
{
    public class Gst
    {
        public double ProAmount { get; set; }
        public double  GstPer { get; set; }
        public double Totalamount { get; set; }

        public Gst(double proAmount,double gstPer)
        {
            this.ProAmount = proAmount;
            this.GstPer = gstPer;
        }

        public double CalculateGstAmount()
        {
            var gstAmount = this.ProAmount / 100 * this.GstPer;
            this.Totalamount = ProAmount + gstAmount;
            return gstAmount;
        }

        public double CalculateGstComposition()
        {
            var gstAmount=this.ProAmount / 100 * 1;
            Totalamount= ProAmount + gstAmount;
            return gstAmount;
        }
    }
}
