﻿using System;

namespace GstLib
{
    internal class Program
    {
        static void Main()
        {
            Gst gst1 = new Gst(1000, 18);
          var gstAmount = gst1.CalculateGstAmount();
            Console.WriteLine($"GST Amount:{gstAmount} and TotalAmount={gst1.Totalamount}");
        }
    }
}
