﻿using System;


namespace ArraysDemo
{
    internal class JaggedArrayDemo
    {
        static void Main()
        {
            //single dim jagged array
            int[][] singleDimJaggedArray = new int[2][];
            singleDimJaggedArray[0] = new int[] { 11, 22, 33 };
            singleDimJaggedArray[1] = new int[] { 44, 55 };

            for (int i = 0; i < 2; i++)
            {
                foreach (var item in singleDimJaggedArray[i])
                {
                    Console.Write($"{item}\t");
                }
                Console.WriteLine();
            }

            //multi. dim jagged array
            int[][,] multiDimJaggedArray = new int[2][,];
            multiDimJaggedArray[0] = new int[,] { { 11, 22, 33 }, { 44, 55, 66 } };
            multiDimJaggedArray[1] = new int[,] { { 56, 67, 78 }, { 56, 78, 67 } };
        }
    }
}
