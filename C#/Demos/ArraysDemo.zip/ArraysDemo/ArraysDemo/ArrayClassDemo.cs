﻿using System;


namespace ArraysDemo
{
    internal class ArrayClassDemo
    {
        static void Main()
        {
            
            int[] nums = { 45,56,3,5,21};
            int[,] nums1 = new int[2, 3];
            int[] dums = new int[5];

            //non-static methods
            nums.CopyTo(dums, 0);
            Console.WriteLine("After copying element from nums to dums");
            foreach (var item in dums)
            {
                Console.Write($"{item}\t");
            }

            Console.WriteLine();
            var lowerbound = dums.GetLowerBound(0);
            var upperbound = dums.GetUpperBound(0);
            Console.WriteLine($"upperbound is:{upperbound} and lower bound is:{lowerbound} of single dim");

            var upperbound1 = nums1.GetUpperBound(1);
            Console.WriteLine($"upperbound of multi dim:{upperbound1} ");

            var multiDimLength = nums1.GetLength(1);
            Console.WriteLine($"Length of multi dim:{multiDimLength}");

            var rank = nums1.Rank;
            Console.WriteLine($"nums1 has { rank} dim.");

            //static methods
            Array.Reverse(dums);
            Console.WriteLine("after performing reverse operation on dums:");
            foreach(var item in dums)
            {
                Console.Write($"{item}\t");
            }

            Console.WriteLine();
            Array.Sort(dums);
            Console.WriteLine("after performing sort on dums:");
            foreach (var item in dums)
            {
                Console.Write($"{item}\t");
            }

            Console.WriteLine();

           var indexOf5= Array.IndexOf(dums, 5);
            Console.WriteLine($"the index of value 5 is:{indexOf5}");

            Array.Clear(dums, 0, 2);
            Console.WriteLine($"after removing first 2 elements from dums:");
            foreach (var item in dums)
            {
                Console.Write($"{item}\t");
            }
        }
    }
}
