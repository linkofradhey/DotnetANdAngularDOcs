﻿using System;


namespace ArraysDemo
{
    internal class MultiDimArrayDemo
    {
        static void Main()
        {
            int[,] nums ={{ 11,22,33},{44,55,66 } };
            int[,] intNums = new int[2,3];

            Console.WriteLine("Enter 6 element:");
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    intNums[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Entered values are:");

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write($"{intNums[i, j]}\t");
                }
                Console.WriteLine();
            }
        }
    }
}
