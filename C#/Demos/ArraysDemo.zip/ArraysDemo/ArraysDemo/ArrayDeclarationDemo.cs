﻿using System;


namespace ArraysDemo
{
    internal class ArrayDeclarationDemo
    {
        static void Main()
        {
            int[] nums = { 45,56,34,56};
            int[] nums1 = new int[] {45,56,78,89 };
            int[] nums2 = new int[5];

            Console.WriteLine("Enter 5 Elements:");
            for (int i = 0; i <nums2.Length ; i++)
            {
                nums2[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("Entered Values Are:");

            foreach (var item in nums2)
            {
                Console.Write($"{item}\t");
            }
        }
    }
}
