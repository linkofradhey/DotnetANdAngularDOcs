﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace LinqDemo
{
    internal class SortingDemo
    {
        static void Main()
        {
            IList<Student> studentList = new List<Student>() {
                new Student() { StudentID= 1, StudentName= "John", Age = 18 } ,
                new Student() { StudentID= 2, StudentName= "Steve",  Age = 15 } ,
                new Student() { StudentID= 3, StudentName= "Bill",  Age = 25 } ,
                new Student() { StudentID= 4, StudentName= "Ram" , Age = 20 } ,
                new Student() { StudentID= 5, StudentName= "Ron" , Age = 19 }
            };

            var sortByAge = studentList.OrderBy(std=>std.Age);
            foreach (var std in sortByAge)
            {
                Console.WriteLine($"{std.StudentID}\t{std.StudentName}\t{std.Age}");
            }

            var sortByAgeDesc = studentList.OrderByDescending(std => std.Age);
            foreach (var std in sortByAgeDesc)
            {
                Console.WriteLine($"{std.StudentID}\t{std.StudentName}\t{std.Age}");
            }
        }
    }
}
