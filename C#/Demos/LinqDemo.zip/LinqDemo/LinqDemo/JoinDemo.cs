﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace LinqDemo
{
    internal class JoinDemo
    {
        static void Main()
        {

            IList<Student> studentList = new List<Student>() {
                new Student() { StudentID = 1, StudentName = "John", Age = 18 } ,
                new Student() { StudentID = 2, StudentName = "Steve",  Age = 21 } ,
                new Student() { StudentID = 3, StudentName = "Bill",  Age = 18 } ,
                new Student() { StudentID = 4, StudentName = "Ram" , Age = 20 } ,
                new Student() { StudentID = 5, StudentName = "Abram" , Age = 21 }
                };

            IList<Marks> markList = new List<Marks>
            {
                new Marks{StudentID=1,TotalMarks=800},
                new Marks{StudentID=2,TotalMarks=770},
                new Marks{StudentID=3,TotalMarks=900},
                new Marks{StudentID=4,TotalMarks=680},
                new Marks{StudentID=5,TotalMarks=700}
            };

            var data = studentList.Join(markList, std => std.StudentID, mark => mark.StudentID, (std, mark) => new
            {
                std.StudentID,std.StudentName,mark.TotalMarks
            });

            foreach (var item in data)
            {
                Console.WriteLine($"{item.StudentID}\t{item.StudentName}\t{item.TotalMarks}");
            }

        }
    }
}
