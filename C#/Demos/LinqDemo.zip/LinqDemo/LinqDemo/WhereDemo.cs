﻿using System;
using System.Collections.Generic;


namespace LinqDemo
{
    internal class WhereDemo
    {
        static void Main()
        {
            
                IList<Student> studentList = new List<Student>() {
                new Student() { StudentID= 1, StudentName= "John", Age = 13} ,
                new Student() { StudentID= 2, StudentName= "Moin",  Age = 21 } ,
                new Student() { StudentID= 3, StudentName= "Bill",  Age = 18 } ,
                new Student() { StudentID= 4, StudentName= "Ram" , Age = 20} ,
                new Student() { StudentID= 5, StudentName= "Ron" , Age = 15 }
                };
            
            //how to write linq query using syntax
            var studentWithAge20=from student in studentList where student.Age>=20 select student;
            foreach (var std in studentWithAge20)
            {
                Console.WriteLine($"{std.StudentID}\t{std.StudentName}\t{std.Age}");
            }

            //how to write linq query using operators/extension methods
            var stdWithAge20 = studentList.Where(std => std.Age >= 20);
            foreach (var std in stdWithAge20)
            {
                Console.WriteLine($"{std.StudentID}\t{std.StudentName}\t{std.Age}");
            }

        }
    }
}
