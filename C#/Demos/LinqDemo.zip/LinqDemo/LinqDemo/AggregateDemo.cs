﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace LinqDemo
{
    internal class AggregateDemo
    {
        static void Main()
        {
            IList<Marks> markList = new List<Marks>
            {
                new Marks{StudentID=1,TotalMarks=800},
                new Marks{StudentID=2,TotalMarks=770},
                new Marks{StudentID=3,TotalMarks=900},
                new Marks{StudentID=4,TotalMarks=680},
                new Marks{StudentID=5,TotalMarks=700}

            };

            var max = markList.Max(m=>m.TotalMarks);
            Console.WriteLine($"Max mark from list:{max}");
            var std = markList.Where(m=>m.TotalMarks.Equals(max)).FirstOrDefault();
            Console.WriteLine($"{std.StudentID}\t{std.TotalMarks}");

            var min = markList.Min(m=>m.TotalMarks);
            Console.WriteLine($"Min mark from list:{min}");
        }
    }
}
