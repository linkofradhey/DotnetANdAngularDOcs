﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace LinqDemo
{
    internal class ElementAtDemo
    {
        static void Main()
        {
            IList<Student> studentList = new List<Student>() {
                new Student() { StudentID= 1, StudentName= "John", Age = 19 } ,
                new Student() { StudentID= 2, StudentName= "Steve",  Age = 18 } ,
                new Student() { StudentID= 3, StudentName= "Bill",  Age = 17 } ,
                new Student() { StudentID= 4, StudentName= "Ram" , Age = 16 } ,
                new Student() { StudentID= 5, StudentName= "Ron" , Age = 17 }
            };

            Console.WriteLine($"Display student from First position");
            var first = studentList.FirstOrDefault();
            Console.WriteLine($"{first.StudentID}\t{first.StudentName}\t{first.Age}");

            Console.WriteLine($"Display student from last position");
            var last = studentList.LastOrDefault();
            Console.WriteLine($"{last.StudentID}\t{last.StudentName}\t{last.Age}");

            Console.WriteLine($"Display student from index 2");
            var index = studentList.ElementAtOrDefault(2);
            Console.WriteLine($"{index.StudentID}\t{index.StudentName}\t{index.Age}");

            Console.WriteLine($"Skip 2 objects and display rest of other objects");
            var skip2 = studentList.Skip(2);
            foreach (var item in skip2)
            {
                Console.WriteLine($"{item.StudentID}\t{item.StudentName}\t{item.Age}");
            }

            Console.WriteLine($"Skip 2 objects and display rest of other objects by sorting it in desc");
            var skip2Desc = studentList.Skip(2).OrderByDescending(std=>std.StudentID);
            foreach (var item in skip2Desc)
            {
                Console.WriteLine($"{item.StudentID}\t{item.StudentName}\t{item.Age}");
            }

        }
    }
}
