﻿using System;


namespace LinqDemo
{
    internal class Student
    {
        public int StudentID { get; set; }
        public string? StudentName { get; set; }
        public int Age { get; set; }
       
    }

    class Marks
    {
        public int StudentID { get; set; }
        public double TotalMarks { get; set; }
    }
}
