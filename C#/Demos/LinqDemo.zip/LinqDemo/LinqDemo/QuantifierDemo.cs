﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace LinqDemo
{
    internal class QuantifierDemo
    {
        static void Main()
        {
            IList<Student> studentList = new List<Student>() {
                new Student() { StudentID= 1, StudentName= "John", Age = 19 } ,
                new Student() { StudentID= 2, StudentName= "Steve",  Age = 18 } ,
                new Student() { StudentID= 3, StudentName= "Bill",  Age = 17 } ,
                new Student() { StudentID= 4, StudentName= "Ram" , Age = 16 } ,
                new Student() { StudentID= 5, StudentName= "Ron" , Age = 17 }
            };

            var isAnyTeenAgers = studentList.Any(std => std.Age > 12 && std.Age<20);
            Console.WriteLine(isAnyTeenAgers ? "Teen Age is there":"There is No Teen Ager");

            var areAllTeenAger = studentList.All(std => std.Age > 12 && std.Age < 20);
            Console.WriteLine(areAllTeenAger?"All students are Teen Agers":"No one is Teen Ager");
        }
    }
}
