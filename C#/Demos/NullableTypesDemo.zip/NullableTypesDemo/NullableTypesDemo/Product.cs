﻿using System;
using System.Collections.Generic;


namespace NullableTypesDemo
{
    internal class Product
    {
        public int ProductId { get; set; }
        public string? ProductName { get; set; }
        public double? Mrp { get; set; }
        public DateTime? ExpiryDate { get; set; }
    }
}
