﻿using System;
using System.Collections.Generic;


namespace NullableTypesDemo
{
    internal class NullableTypeDemo
    {
        static void Main()
        {
            Product product1 = new Product { ProductId = 111, ProductName = "Shampoo", Mrp = null, ExpiryDate = DateTime.Parse("24-09-2027") };
            Console.WriteLine($"{product1.ProductId}\t{product1.ProductName}\t{product1.Mrp}\t{product1.ExpiryDate}");

            var mrp = product1.Mrp ?? 1;
            Console.WriteLine($"Mrp={mrp}");
        }
    }
}
