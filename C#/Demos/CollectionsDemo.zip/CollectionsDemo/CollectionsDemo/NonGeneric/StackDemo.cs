﻿using System;
using System.Collections;

namespace CollectionsDemo.NonGeneric
{
    internal class StackDemo
    {
       static void Main()
        {
            Stack stk=new Stack();
            stk.Push(100);//conversion will happen at runtime
            stk.Push(101);
            stk.Push(102);
            stk.Push(103);

            Console.WriteLine($"Count={stk.Count}");
            foreach (var item in stk)
            {
                Console.WriteLine(item);
            }

            var removed = stk.Pop();
            Console.WriteLine($"{removed} is removed");
            Console.WriteLine($"After removing wan element:{removed}");
            foreach (var item in stk)
            {
                Console.WriteLine(item);
            }

            var top = stk.Peek();
            Console.WriteLine($"Top element is :{top}");

            stk.Clear();
            Console.WriteLine("After Alearing Stack");
            Console.WriteLine($"Count={stk.Count}");
            foreach (var item in stk)
            {
                Console.WriteLine(item);
            }
        }
    }
}
