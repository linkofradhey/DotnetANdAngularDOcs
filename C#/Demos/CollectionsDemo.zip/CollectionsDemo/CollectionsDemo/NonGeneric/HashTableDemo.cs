﻿using System;
using System.Collections;

namespace CollectionsDemo.NonGeneric
{
    internal class HashTableDemo
    {
        static void Main()
        {
            Hashtable gstStateCode=new Hashtable();
            gstStateCode.Add("MH", 27);
            gstStateCode.Add("GJ",24);
            gstStateCode.Add("TL",31);
            gstStateCode.Add("DL",30);

            Console.WriteLine($"Count={gstStateCode.Count}");
            var gjCode = gstStateCode["GJ"];
            Console.WriteLine($"GST State Code for Gujarat is:{gjCode}");

            gstStateCode["GJ"] = 21;
            gjCode = gstStateCode["GJ"];
            Console.WriteLine($"Updated GST State Code for Gujarat is:{gjCode}");

            var keys = gstStateCode.Keys;
            Console.WriteLine("GST State Code Details are:");

            foreach (var key in keys)
            {
                Console.WriteLine($"Key={key} and Value={gstStateCode[key]}");   
            }

            gstStateCode.Remove("GJ");
            Console.WriteLine("After removing GJ:");
            keys=gstStateCode.Keys;
            foreach (var key in keys)
            {
                Console.WriteLine($"Key={key} and Value={gstStateCode[key]}");
            }

        }
    }
}
