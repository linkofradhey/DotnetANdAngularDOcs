﻿using System;
using System.Collections;
using System.Net.Http.Headers;


namespace CollectionsDemo.NonGeneric
{
    internal class ArrayListDemo
    {
        static void Main()
        {
            ArrayList stdArray = new ArrayList();
            stdArray.Add(100); //RollNo  //This conversion (boxing) will happen at runtime
            stdArray.Add("Scott");//Name
            stdArray.Add('M');//Gender
            stdArray.Add(true);//IsNewlyEnrolled
            stdArray.Add(7856344543);//MobileNo
            stdArray.Capacity = stdArray.Count;
            Console.WriteLine($"Count={stdArray.Count} and Capacity={stdArray.Capacity}");

            // stdArray[1];//Scott

            foreach (var std in stdArray)
            {
                Console.Write($"{std}\t");
            }

            Console.WriteLine();
            stdArray.Remove("Scott");
            stdArray.Capacity=stdArray.Count;
            Console.WriteLine($"Count={stdArray.Count} and Capacity={stdArray.Capacity}");
            Console.WriteLine("After Removing second element from collection:");
            foreach (var std in stdArray)
            {
                Console.Write($"{std}\t");
            }

            Console.WriteLine();
            var isExist=  stdArray.Contains(100);
            Console.WriteLine(isExist?"RollNo 100 is exist":"RollNo 100 is NOT exist");


            stdArray.Clear();
            stdArray.Capacity = stdArray.Count;
            Console.WriteLine("After clearing all the elements:");
            Console.WriteLine($"Count={stdArray.Count} and Capacity={stdArray.Capacity}");
            foreach (var std in stdArray)
            {
                Console.Write($"{std}\t");
            }
        }
    }
}
