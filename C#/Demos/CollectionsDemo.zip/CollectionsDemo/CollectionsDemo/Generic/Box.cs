﻿using System;
using System.Collections.Generic;


namespace CollectionsDemo.Generic
{
    internal class Box<T>
    {
        private T content;

        public void Add(T item)
        {
            content = item;
        }
         
        public T Get()
        {
            return  content;
        }
    }

    class Utility
    {
        public void Print<T>(T item)
        {
            Console.WriteLine(item);
        }
    }
    class Program
    {
        static void Main()
        {
            Box<int> intBox = new Box<int>();
            intBox.Add(100);
            Console.WriteLine(intBox.Get());

            Box<string> strBox = new Box<string>();
            strBox.Add("Welcome");
            Console.WriteLine(strBox.Get());

            Utility util=new Utility();
            util.Print<int>(100);
            util.Print<string>("welcome");

        }
    }
}
