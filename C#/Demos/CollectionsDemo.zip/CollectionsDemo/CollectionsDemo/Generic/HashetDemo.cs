﻿using System;
using System.Collections.Generic;


namespace CollectionsDemo.Generic
{
    internal class HashetDemo
    {
       static void Main()
        {
            HashSet<int> intSet = new HashSet<int>();
            intSet.Add(100);
            intSet.Add(101);
            intSet.Add(102);
            intSet.Add(100);
            intSet.Add(102);

            Console.WriteLine($"Count is:{intSet.Count}");

            foreach(var num in intSet)
            {
                Console.WriteLine(num);
            }

            intSet.Remove(101);

            Console.WriteLine($"After removing 101");
            foreach (var num in intSet)
            {
                Console.WriteLine(num);
            }
        }
    }
}
