﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace CollectionsDemo.Generic
{
    internal class ListDemo
    {
        static void Main()
        {
            List<int> intList=new List<int>(); //conversion happening at compile-time
            intList.Add(100);
            // intList.Add("scott"); //error


            //List<Student> stdList = new List<Student>();//conversion happening at compile-time
            //Student std1 = new Student { RollNo=100,StdName="Scott",Gender='M',IsNewlyEnrolled=true,MobileNo=7656546545}; //object init.

            //stdList.Add(std1);

            //collection init.
            List<Student> stdList = new List<Student>
            {
                new Student{RollNo=100,StdName="Scott",Gender='M',IsNewlyEnrolled=true,MobileNo=7656546545},
                new Student{RollNo=101,StdName="Tiger",Gender='M',IsNewlyEnrolled=true,MobileNo=7676576845},
                new Student{RollNo=102,StdName="Smith",Gender='M',IsNewlyEnrolled=false,MobileNo=7657586545}
            };

            stdList.Capacity = stdList.Count;

            Console.WriteLine($"Count={stdList.Count} and Capacity={stdList.Capacity}");

            foreach (var std in stdList)
            {
                Console.WriteLine($"{std.RollNo}\t{std.StdName}\t{std.Gender}\t{std.IsNewlyEnrolled}\t{std.MobileNo}");
            }

            stdList.Remove(stdList[1]);

            stdList.Capacity = stdList.Count;
            Console.WriteLine("After removing student Tiger:");
            Console.WriteLine($"Count={stdList.Count} and Capacity={stdList.Capacity}");
            foreach (var std in stdList)
            {
                Console.WriteLine($"{std.RollNo}\t{std.StdName}\t{std.Gender}\t{std.IsNewlyEnrolled}\t{std.MobileNo}");
            }

            stdList.Clear();

        }
    }
}
