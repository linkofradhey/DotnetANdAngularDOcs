﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization.Json;


namespace CollectionsDemo.Generic
{
    internal class DictionaryDemo
    {
        static void Main()
        {
            Dictionary<string, int> gstStateCodes = new Dictionary<string, int>();
            gstStateCodes.Add("MH", 27);
            gstStateCodes.Add("GJ",24);
            gstStateCodes.Add("TL",31);
            gstStateCodes.Add("DL",30);

            Console.WriteLine($"Count={gstStateCodes.Count}");
            var mhCode = gstStateCodes["MH"];
            Console.WriteLine($"GST State Code for MH is:{mhCode}");

            var keys = gstStateCodes.Keys;
            foreach (var key in keys)
            {
                Console.WriteLine($"Key={key} and Value={gstStateCodes[key]}");
            }

            //Sorted List<T,T>
            SortedList<string,int> sortedList=new SortedList<string,int>(gstStateCodes);
            Console.WriteLine($"Count for SortedList is={sortedList.Count} ");
            var sortedKeys = sortedList.Keys;
            foreach (var key in sortedKeys)
            {
                Console.WriteLine($"Key={key} and Value={gstStateCodes[key]}");
            }


            //SortedList<Student,ClassRoom>
            //SortedList<Student, ClassRoom> classRoomMapping = new SortedList<Student, ClassRoom>
            //{
            //    {new Student{RollNo=100,StdName="Scott",Gender='M',IsNewlyEnrolled=true,MobileNo=7656546545},
            //    new ClassRoom{RoomNo=10,Floor="1St"} },
            //    {new Student{RollNo=101,StdName="Tiger",Gender='M',IsNewlyEnrolled=true,MobileNo=7656748545},
            //    new ClassRoom{RoomNo=10,Floor="1St"} },

            //};

            Dictionary<Student, ClassRoom> classRoomMapping = new Dictionary<Student, ClassRoom>
            {
                {new Student{RollNo=100,StdName="Scott",Gender='M',IsNewlyEnrolled=true,MobileNo=7656546545},
                new ClassRoom{RoomNo=10,Floor="1St"} },
                {new Student{RollNo=101,StdName="Tiger",Gender='M',IsNewlyEnrolled=true,MobileNo=7656748545},
                new ClassRoom{RoomNo=10,Floor="1St"} },

            };

            Console.WriteLine($"Count={classRoomMapping.Count}");
            var classRoomKeys=classRoomMapping.Keys;
            foreach (var std in classRoomKeys)
            {
                Console.WriteLine($"{std.StdName}\t {std.RollNo}={classRoomMapping[std].RoomNo}\t {classRoomMapping[std].Floor}");
            }

        }
    }
}
