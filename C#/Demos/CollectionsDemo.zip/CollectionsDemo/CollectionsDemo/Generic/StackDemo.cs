﻿using System;
using System.Collections.Generic;


namespace CollectionsDemo.Generic
{
    internal class StackDemo
    {
        static void Main()
        {
            Stack<Student> stkStudent = new Stack<Student>();

            Student std1 = new Student { RollNo = 100, StdName = "Scott", Gender = 'M', IsNewlyEnrolled = true, MobileNo = 7656546545 };
            Student std2 = new Student { RollNo = 101, StdName = "Tiger", Gender = 'M', IsNewlyEnrolled = true, MobileNo = 7676576845 };
            Student std3 = new Student { RollNo = 102, StdName = "Smith", Gender = 'M', IsNewlyEnrolled = false, MobileNo = 7657586545 };

            stkStudent.Push(std1);
            stkStudent.Push(std2);
            stkStudent.Push(std3);

            Console.WriteLine($"Count={stkStudent.Count}");
            foreach (var student in stkStudent)
            {
                Console.WriteLine($"{student.RollNo}\t{student.StdName}\t{student.Gender}\t{student.IsNewlyEnrolled}\t{student.MobileNo}");
            }

          var removed=  stkStudent.Pop();
            Console.WriteLine($"After removing {removed.StdName}");
            Console.WriteLine($"Count={stkStudent.Count}");
            foreach (var student in stkStudent)
            {
                Console.WriteLine($"{student.RollNo}\t{student.StdName}\t{student.Gender}\t{student.IsNewlyEnrolled}\t{student.MobileNo}");
            }

        }
    }
}
