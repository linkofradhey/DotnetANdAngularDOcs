﻿using System;
using System.Collections.Generic;


namespace CollectionsDemo.Generic
{
    internal class Product
    {
        public int ProCode { get; set; }
        public string ProName { get; set; }
        public string ProCategory { get; set; }
        public double Mrp { get; set; }
    }
}
