﻿using System;


namespace CollectionsDemo.Generic
{
    internal class Student
    {
        public int RollNo { get; set; }
        public string StdName { get; set; }
        public char Gender { get; set; }
        public bool IsNewlyEnrolled { get; set; }
        public long MobileNo { get; set; }

    }

    class ClassRoom
    {
        public int RoomNo { get; set; }
        public string Floor { get; set; }
    }
}
