﻿using System;
using System.Collections.Generic;


namespace CollectionsDemo.Generic
{
    internal class ProductCatalogDemo
    {
        static List<Product> products = new List<Product>();
        static void Main()
        {
            start:
            Console.Write("Please Enter\t 1.To Add a Product in the Catalog.\t2.To Remove Product\t3.Print All The Product\t4.Search Product By Code \t5.Search Product by Name:");
            int choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:

                    AddProduct(new Product { ProCode = 100, ProName = "Toothpaste", ProCategory = "FMCG", Mrp = 10 });
                    ShowProductCatalog();
                    break;
                case 2:
                    Console.Write("Please Enter Product Code to Remove:");
                    int proCodeToRemove= Convert.ToInt32(Console.ReadLine());
                    RemoveProduct(proCodeToRemove);
                    ShowProductCatalog();
                    break;
                case 3:
                    ShowProductCatalog();
                    break;
                case 4:
                    Console.Write("Please Enter Product Code to Search:");
                    int proCodeToSearch = Convert.ToInt32(Console.ReadLine());
                    SearchProductByCode(proCodeToSearch);
                    break;
                case 5:
                    Console.Write("Please Enter a Product Name to Search:");
                    string name = Console.ReadLine();
                    SearchProductByName(name);

                    break;
                default:
                    Console.WriteLine("Invalid Choice");
                    break;
            }

            Console.Write("Do you want to continue (yes/no):");
            string ans=Console.ReadLine();
            if(ans is "yes")
            {
                goto start;
            }
        }

        static void AddProduct(Product newProduct)
        {
            products.Add(newProduct);
        }

        static void ShowProductCatalog()
        {
            Console.WriteLine($"Product Catalog has {products.Count} product");
            foreach (var product in products)
            {
                Console.WriteLine($"{product.ProCode}\t{product.ProName}\t{product.ProCategory}\t{product.Mrp}");
            }
        }

        static void RemoveProduct(int code)
        {
            var existingProduct=products.Where(pro=>pro.ProCode== code).FirstOrDefault();
            if (existingProduct != null)
            {
                products.Remove(existingProduct);
            }
        }

        static void SearchProductByCode(int code)
        {
           var productByCode= products.Where(pro => pro.ProCode == code).FirstOrDefault();
            if (productByCode != null)
            {
                Console.WriteLine($"{productByCode.ProCode}\t{productByCode.ProName}\t{productByCode.ProCategory}\t{productByCode.Mrp}");
            }
            else
            {
                Console.WriteLine("Product does not exist");
            }
        }

        static void SearchProductByName(string name)
        {
            var productByName = products.Where(pro => pro.ProName == name).FirstOrDefault();
          
            Console.WriteLine($"{productByName.ProCode}\t{productByName.ProName}\t{productByName.ProCategory}\t{productByName.Mrp}");
        }
    }
}
