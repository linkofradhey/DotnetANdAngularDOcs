﻿using System;


namespace OopDemo
{
    internal class SingleInheritanceDemo
    {
        static void Main()
        {
            Nokia1100 nokia1 = new Nokia1100();

            Nokia1100 nokia1100 = new Nokia1100(223, "Nokia1100", 20);
            Console.WriteLine(nokia1100.Calling());
            Console.WriteLine(nokia1100.SendSMS());
            Console.WriteLine(nokia1100.Mp3());
            Console.WriteLine(nokia1100.DisplayDetails());
        }
    }
}
