﻿
using System;


namespace OopDemo
{
    internal class Program
    {
        static void Main()
        {
            //MobilePhone mobilePhone1 = new MobilePhone();

            MobilePhone mobilePhone2 = new MobilePhone(123,"Galaxy",10);
            Console.WriteLine(mobilePhone2.Calling());
            Console.WriteLine(mobilePhone2.SendSMS()) ;
            Console.WriteLine(mobilePhone2.DisplayDetails());

          
        }
    }
}
