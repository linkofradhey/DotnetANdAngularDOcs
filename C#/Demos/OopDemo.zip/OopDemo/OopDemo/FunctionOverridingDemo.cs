﻿using System;


namespace OopDemo
{
    internal class FunctionOverridingDemo
    {
        static void Main()
        {
            MyMath2 myMath2 = new MyMath2();
           var doubleDiscount= myMath2.CalculateDiscount(1000, 10);
            Console.WriteLine($"Double Discount is:{doubleDiscount}");

            //call ToString() overriden version
            Employee emp1 = new Employee { EmpCode = 100, EmpName = "Scott", Email = "scott@gmail.com" };
           Console.WriteLine( emp1.ToString());

            Employee emp2 = new Employee { EmpCode = 101, EmpName = "Tiger", Email = "tiger@gmail.com" };
           var isSame= emp1.Equals(emp2);
            Console.WriteLine(isSame?"Both employees are same":"Both are different employees");
        }
    }
}
