﻿using System;


namespace OopDemo
{
    internal class FunctionOverloadingDemo
    {
        static void Main()
        {
            MyMath myMath = new MyMath();
            var areaOfRectangle = myMath.Area(20, 40);
            Console.WriteLine($"Area of Rectangle is:{areaOfRectangle}");

            var areaOfCircle = myMath.Area(5);
            Console.WriteLine($"Area of Circle is:{areaOfCircle}");
        }
    }
}
