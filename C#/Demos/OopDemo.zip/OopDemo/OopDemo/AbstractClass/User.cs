﻿using System;


namespace OopDemo.AbstractClass
{
    internal abstract class User
    {
        public int UserId { get; set; } //concrete member
        public string UserName { get; set; }//concrete member
        public abstract string UserType { get; set; } //abstract member

        public User()
        {
            
        }

        //concrete member
        public bool ValidateUser(int userId,string userName)
        {
           if(userId is 101 && userName is "Admin")
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        //abstract member
        public abstract string LogOut();
    }

    class Admin : User
    {
        //public sealed override string UserType { get; set; } = "Admin";

        public override string UserType { get; set; } = "Admin";

        //public sealed override string LogOut()
        //{
        //    return $"User:{this.UserName} and Type:{this.UserType} is LoggedOut";
        //}

        public  override string LogOut()
        {
            return $"User:{this.UserName} and Type:{this.UserType} is LoggedOut";
        }
    }

    class PowerAdmin : Admin
    {
        public sealed override string UserType { get; set; } = "Power Admin";
        public sealed override string LogOut()
        {
            return $"User:{this.UserName} and Type:{this.UserType} is LoggedOut";
        }
    }
}
