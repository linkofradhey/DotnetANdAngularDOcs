﻿using System;


namespace OopDemo.AbstractClass
{
    internal class UseAbstractClassDemo
    {
        static void Main()
        {
            // User user1 = new User(); //error
            Admin admin1 = new Admin { UserId = 101, UserName = "Admin" };
            var isValidated = admin1.ValidateUser(admin1.UserId, admin1.UserName);
            Console.WriteLine(isValidated?"User is Valid":"User is NOT valid");

        }
    }
}
