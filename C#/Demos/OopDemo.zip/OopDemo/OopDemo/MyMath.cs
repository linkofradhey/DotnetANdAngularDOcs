﻿using System;
using System.Transactions;


namespace OopDemo
{
    internal class MyMath
    {
        //static/compile-time polymorphism

        //area of reactangle
        public int Area(int height,int width)
        {
            return  height * width;
        }

        //area of circle
        public double Area(int radius)
        {
            return Math.PI * radius*radius;          
        }

        //flat-discount
        public virtual double CalculateDiscount(double proAmount,double per)
        {
            var disAmount = proAmount / 100 * per;
            return disAmount;
        }

    }

    class MyMath2 : MyMath 
    {
        //dynamic/runtime ploymorphism    
        public  override double CalculateDiscount(double proAmount, double per)
        {
            //flat discount
            var disAmount=proAmount / 100 * per;
            if (proAmount >= 1000)
            {
                //double discount
                disAmount += 100;
                return disAmount;
            }
            else
            {
                return disAmount;
            }
        }

        //shadow of base class version
        public new double Area(double height,double width)
        {
            return (height * width);
        }
    }

    class MyMath3 : MyMath2
    {
      
    }
}
