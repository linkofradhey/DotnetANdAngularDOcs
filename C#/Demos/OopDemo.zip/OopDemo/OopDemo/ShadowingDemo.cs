﻿using System;


namespace OopDemo
{
    internal class ShadowingDemo
    {
        static void Main()
        {
            MyMath2 myMath2 = new MyMath2();
          var area=  myMath2.Area(23, 45);
            Console.WriteLine($"Area of Rectangle is:{area}");
        }
    }
}
