﻿using System;
using System.Runtime.CompilerServices;


namespace OopDemo.SealedClass
{
    internal class UseSealedClassDemo
    {
        static void Main()
        {
            Guest guest1 = new Guest { UserId = 101, UserName = "Guest" };
           var isValidated= guest1.ValidateUser(guest1.UserId,guest1.UserName);
            Console.WriteLine(isValidated);
        }
    }
}
