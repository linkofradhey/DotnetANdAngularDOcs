﻿using OopDemo.AbstractClass;
using System;


namespace OopDemo.SealedClass
{
    internal sealed class Guest:User
    {
        public sealed override string UserType { get; set; } = "Guest";
        public sealed override string LogOut()
        {
            return $"UserId:{this.UserId} and UserName:{this.UserName} is LoggedOut";
        }
    }
}
