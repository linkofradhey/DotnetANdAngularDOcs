﻿using System;

namespace OopDemo.Constructor
{
    internal class CopyConstructorDemo
    {
        static void Main()
        {
            Student student1 = new Student {RollNo=100,Name="Scott",Email="scott@gmail.com" };
            Student student2 = new Student(student1);
            Console.WriteLine($"{student2.RollNo}\t{student2.Name}\t{student2.Email}");
        }
    }
}
