﻿using System;


namespace OopDemo.Constructor
{
    internal class Student
    {
        public int RollNo { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

        public Student()
        {
            
        }

        public Student(int rollNo,string name,string email)
        {
            this.RollNo = rollNo;
            this.Name= name;
            this.Email = email;
        }

        //copy constructor
        public Student(Student student)
        {
            this.RollNo = student.RollNo;
            this.Name=student.Name;
            this.Email = student.Email;
        }

        ~Student()
        {
            //implicity it invokes Finalize method of System.Object
        }
    }
}
