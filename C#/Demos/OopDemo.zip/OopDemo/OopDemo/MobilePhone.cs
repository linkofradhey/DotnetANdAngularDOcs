﻿using System;


namespace OopDemo
{
    internal class MobilePhone
    {
        public int ModelNo { get; set; }
        public string ModelName { get; set; }
        public int InternalStorage { get; set; }

        //default constructor
        //1.To create memory for an object
        //2.To init. all public prop and functions
        public MobilePhone()
        {
            Console.WriteLine("default constructor of MobilePhone");
        }

        public MobilePhone(int modelNo,string modelName,int internalStorage)
        {
            this.ModelNo = modelNo;
            this.ModelName = modelName;
            this.InternalStorage = internalStorage;
        }

        public string Calling()
        {
            return $"Calling() from MobilePhone";
        }

        public string SendSMS()
        {
            return $"SendSMS() from MobilePhone";
        }

        public string DisplayDetails()
        {
            return $"Model No={this.ModelNo}\nModel Name={this.ModelName}\nInternal Storage={this.InternalStorage}";
        }

    }
}
