﻿using System;


namespace OopDemo.PartialClass
{
    internal class UsePartialClassDemo
    {
        static void Main()
        {
            Payment payment1 = new Payment("abc@ybl");
           Console.WriteLine( payment1.ProcessUpiPayment());
        }
    }
}
