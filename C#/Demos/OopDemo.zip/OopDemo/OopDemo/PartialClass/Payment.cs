﻿using System;


namespace OopDemo.PartialClass
{
    //UPI Payment
    internal partial class Payment
    {
        //constructor
        public Payment(string upiId)
        {
            Console.WriteLine($"Payment with UPI Id:{upiId}");
        }

        public string ProcessUpiPayment()
        {
            return $"Processing UPI Payment";
        }
    }

    //Net banking Payment
    partial class Payment
    {
        public Payment(string userId,string bankName)
        {
            Console.WriteLine($"Payment with NetBanking:{userId}\t{bankName}");
        }

        public string ProcessNetBankingPayment()
        {
            return $"Processing Netbanking Payment";
        }

    }
}
