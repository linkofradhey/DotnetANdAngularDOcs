﻿using OopDemo.Constructor;
using System;


namespace OopDemo.PropertiesExamples
{
    internal class PropDemo
    {
        static void Main()
        {
            Product product1 = new Product { ProductId = 111, ProductName = "Milk", ProductCategory = null };
            Console.WriteLine($"{product1.ProductId}\t{product1.ProductName}\t{product1.ProductCategory}");
            //product1.MadeIn = "China"; //error:read-only

            //complex property
            List<Product> products = new List<Product>
            {
                new Product { ProductId = 111, ProductName = "Milk", ProductCategory = "FMCG" },
                new Product { ProductId = 112, ProductName = "Butter-Milk", ProductCategory = "FMCG" }
            };

            Order order1 = new Order();
            order1.OrderId = 1;
            order1.OrderDate = DateTime.Now.Date;
            order1.Products = products;

            foreach (var product in order1.Products)
            {
                Console.WriteLine($"{product.ProductId}\t{product.ProductName}\t{product.ProductCategory}");
            }


        }
    }
}
