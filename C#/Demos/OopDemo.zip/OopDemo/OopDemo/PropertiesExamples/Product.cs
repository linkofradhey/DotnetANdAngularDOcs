﻿using System;


namespace OopDemo.PropertiesExamples
{
    public class Product
    {
        //Auto-Implemented Properties
        public int ProductId { get; set; }
        public string ProductName { get; set; }

        //Manually Implemented Properties
        private string _ProductCategory;


        //read-write prop
        public string ProductCategory
        {
            get
            {
                return _ProductCategory;
            }
            set
            {
                if (value != null || value is "")
                {
                    _ProductCategory = value;
                }
                else
                {
                    _ProductCategory = "Unknown";
                }
            }
        }

        //read-only prop
        public string MadeIn
        {
            get
            {
                return "Made in India";
            }
        }

        public DateTime ExpiryDate { get; set; }
    }

    class Order
    {
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; }
        public double TotalAmount { get; set; }
        public List<Product> Products { get; set; }
    }
}
