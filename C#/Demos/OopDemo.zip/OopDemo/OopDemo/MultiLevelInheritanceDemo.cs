﻿using System;


namespace OopDemo
{
    internal class MultiLevelInheritanceDemo
    {
        static void Main()
        {
            Nokia1400 nokia1400 = new Nokia1400(445, "Nokia1400", 20,100);
           Console.WriteLine( nokia1400.Calling());
            Console.WriteLine(nokia1400.SendSMS());
            Console.WriteLine(nokia1400.Mp3());
            Console.WriteLine(nokia1400.Mp4());
            Console.WriteLine(nokia1400.Nokia1400Details());
        }
    }
}
