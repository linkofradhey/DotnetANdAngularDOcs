﻿using System;


namespace OopDemo.StaticClass
{
    internal static class IntExtension
    {
        public static bool IsGreaterThan(this int firstNum,int secondNum)
        {
            return firstNum > secondNum;
        }
    }

    static class StringExtension 
    { 
        public static string ValidateLength(this string str)
        {
            return str.Length > 8 ? "Password is Strong" : "Password is Weak";
        }

        public static string ConvertToLower(this string str)
        {
            return str.ToLowerInvariant();
        }
    }
}
