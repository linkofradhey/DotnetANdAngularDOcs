﻿using System;


namespace OopDemo.StaticClass
{
    internal class UseExtensionMethodDemo
    {
        static void Main()
        {
            int num1 = 20, num2 = 10;
           var isGreaterThan= num1.IsGreaterThan(num2);
            Console.WriteLine(isGreaterThan?"First Number is Greater than second":"Second Number is Greater than first");

            string password = "abcdef";
          var isStrong=  password.ValidateLength();
            Console.WriteLine(isStrong);

          
            var lower = password.ValidateLength().ConvertToLower();
            Console.WriteLine(isStrong);
        }
    }
}
