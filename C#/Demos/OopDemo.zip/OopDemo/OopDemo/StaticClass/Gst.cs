﻿using System;
using System.Runtime.CompilerServices;


namespace OopDemo.StaticClass
{
    internal static class Gst
    {
        public static double ProAmount { get; set; }
        public static double Per { get; set; }
        static Gst()
        {
            Console.WriteLine("Static Constructor from Gst");
        }
        public  static double CalculateGst()
        {
            var gstAmount = ProAmount / 100 * Per;
            return gstAmount;
        }
    }
}
