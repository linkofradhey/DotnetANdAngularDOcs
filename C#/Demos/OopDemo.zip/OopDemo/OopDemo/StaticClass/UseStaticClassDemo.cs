﻿using System;

namespace OopDemo.StaticClass
{
    internal class UseStaticClassDemo
    {
       static void Main()
        {
            Gst.ProAmount = 1000;
            Gst.Per = 18;
            var gstAmount = Gst.CalculateGst();
            Console.WriteLine($"GST Amount is:{gstAmount}");

            Gst.ProAmount = 2000;
            Gst.Per = 18;
            var gstAmount1 = Gst.CalculateGst();
            Console.WriteLine($"GST Amount is:{gstAmount1}");
        }
    }
}
