﻿using System;


namespace OopDemo
{
    internal class Nokia1100:MobilePhone
    {
        public Nokia1100()
        {
            Console.WriteLine("default constructor of Nokia1100");
        }

        public Nokia1100(int modelNo,string modelName,int InternalStorage) : base(modelNo, modelName, InternalStorage)
        {

        }

        public string Mp3()
        {
            return $"Mp3() calling from Nokia1100";
        }
    }
}
