﻿using System;


namespace OopDemo.InterfaceExamples
{
    internal interface IWifi
    {
         string SSID { get; set; }
        string StartWifi();

        string StopWifi();

        string TroubleShoot();
    }
}
