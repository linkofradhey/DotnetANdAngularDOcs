﻿using System;


namespace OopDemo.InterfaceExamples
{
    internal class MultipleInheritanceWithInterfaceDemo
    {
        static void Main()
        {
            NokiaLumia nokiaLumia = new NokiaLumia { ModelNo = 222, ModelName = "Nokia Lumia", InternalStorage = 10,SSID="wifi1" };
          Console.WriteLine(  nokiaLumia.Calling());
            Console.WriteLine(nokiaLumia.SendSMS());
            Console.WriteLine($"{nokiaLumia.DisplayDetails()}\t{nokiaLumia.SSID}");
           // Console.WriteLine(nokiaLumia.StartWifi());
            Console.WriteLine(nokiaLumia.StopWifi());
           Console.WriteLine( nokiaLumia.PushMessage());
            Console.WriteLine(nokiaLumia.TroubleShoot()); //throws exception

            //calling explicit implementations
            IWifi wifi = new NokiaLumia();
          Console.WriteLine(  wifi.StartWifi());

        }
    }
}
