﻿using System;
using System.Reflection.Metadata.Ecma335;

namespace OopDemo.InterfaceExamples
{
    internal interface IVehicle
    {
        public int VehicleId { get; set; }
        public string VehicleName { get; set; }
        public string StartVehicle();
        public string StopVehicle();
    }

    interface ICommercialVehicle : IVehicle
    {
        public string CommercialVehicleType { get; set; }
        public int LoadingCapacity { get; set; }
        public string ToLoad();
        public string ToUnLoad();
    }

    class CommercialVehicle : ICommercialVehicle
    {
        public string CommercialVehicleType { get ; set ; }
        public int LoadingCapacity { get ; set ; }
        public int VehicleId { get ; set ; }
        public string VehicleName { get ; set ; }

        public string StartVehicle()
        {
            return $"Starting a Commercial Vehicle";
        }

        public string StopVehicle()
        {
            return $"Stopping a Commercial Vehicle";
        }

        public string ToLoad()
        {
            return $"Loading a Commercials Vehicle";
        }

        public string ToUnLoad()
        {
            return $"Unloading  Commercial Vehicle";
        }
    }

    interface INonCommercialVehicle : IVehicle
    {
        public string NonCommercialVehicleType { get; set; }
        public int SittingCapacity { get; set; }

        public string SwitchFuelType();
       
    }

    class NonCommercialVehicle : INonCommercialVehicle
    {
        public string NonCommercialVehicleType { get ; set ; }
        public int SittingCapacity { get ; set ; }
        public int VehicleId { get ; set; }
        public string VehicleName { get ; set ; }

        public string StartVehicle()
        {
            return "Starting Non-Commercial Vehicle";
        }

        public string StopVehicle()
        {
            return "Stopping Non-Commercial Vehicle";
        }

        public string SwitchFuelType()
        {
            return $"Switching Fuel Type"; 
        }
    }
}
