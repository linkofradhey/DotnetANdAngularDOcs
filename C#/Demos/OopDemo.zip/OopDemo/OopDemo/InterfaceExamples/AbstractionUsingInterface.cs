﻿using System;


namespace OopDemo.InterfaceExamples
{
    internal class AbstractionUsingInterface
    {
        static void Main()
        {
            CommercialVehicle commercialVehicle = new CommercialVehicle();
            commercialVehicle.VehicleId = 45656;
            commercialVehicle.VehicleName = "Tata Pickup";
            commercialVehicle.CommercialVehicleType = "Four Wheeler";
            commercialVehicle.LoadingCapacity = 4000;
           Console.WriteLine( commercialVehicle.StartVehicle());
            Console.WriteLine(commercialVehicle.StopVehicle());
            Console.WriteLine($"{commercialVehicle.VehicleId}\t{commercialVehicle.VehicleName}\t{commercialVehicle.LoadingCapacity}");
        }
    }
}
