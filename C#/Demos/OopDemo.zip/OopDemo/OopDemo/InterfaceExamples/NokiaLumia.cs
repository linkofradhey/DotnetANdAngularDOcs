﻿using System;


namespace OopDemo.InterfaceExamples
{
    internal class NokiaLumia : MobilePhone, IWifi
    {
        public string SSID { get ; set ; }

        //public string StartWifi()
        //{
        //    return $"Starting Wifi Service";
        //}

        public string StopWifi()
        {
            return $"Stopping Wifi Service";
        }

        public string TroubleShoot()
        {
            throw new NotImplementedException();
        }

        public string PushMessage()
        {
            return $"PushMessage() calling from NokiaLumia";
        }

        //explicit implementation
        string IWifi.StartWifi()
        {
            return $"Starting Wifi Service";
        }
    }
}
