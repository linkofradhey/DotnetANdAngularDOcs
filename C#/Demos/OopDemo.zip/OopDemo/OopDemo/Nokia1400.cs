﻿using System;


namespace OopDemo
{
    internal class Nokia1400:Nokia1100
    {
        public int CameraPixel { get; set; }
        public Nokia1400()
        {
            Console.WriteLine("default constructor of Nokia1400");
        }

        public Nokia1400(int modelNo,string modelName,int internalStorage,int cameraPixel):base(modelNo,modelName,internalStorage)
        {
            this.CameraPixel= cameraPixel;
        }

        public string Mp4()
        {
            return $"Mp4() calling from Nokia1400";
        }

        public string Nokia1400Details()
        {
            var baseDetails = base.DisplayDetails();
            return $"{baseDetails}\nCamera Pixel={this.CameraPixel}";
        }
    }
}
