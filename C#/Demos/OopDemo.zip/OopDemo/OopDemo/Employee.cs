﻿using System;


namespace OopDemo
{
    internal class Employee
    {
        public int EmpCode { get; set; }
        public string  EmpName { get; set; }
        public string Email { get; set; }

        public override string ToString()
        {
            return $"{this.EmpCode}\t{this.EmpName}\t{this.Email}";
        }

        public override bool Equals(object? obj)
        {
            var emp=obj as Employee;
            return (this.EmpCode==emp.EmpCode);
        }

    }
}
