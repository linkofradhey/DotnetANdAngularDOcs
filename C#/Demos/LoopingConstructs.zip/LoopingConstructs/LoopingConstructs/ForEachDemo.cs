﻿using System;


namespace LoopingConstructs
{
    internal class ForEachDemo
    {
        static void Main()
        {
            
            int[] nums = { 34,56,78,79};
            int sum = 0;
            //for (int i = 0; i < 4; i++)
            //{
            //    sum = sum + nums[i];
            //    Console.WriteLine(sum);
            //}

            foreach (var item in nums)
            {
                sum = sum + item;
                Console.WriteLine(sum);
            }
        }
    }
}
