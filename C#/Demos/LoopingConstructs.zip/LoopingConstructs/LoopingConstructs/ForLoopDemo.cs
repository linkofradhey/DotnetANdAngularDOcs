﻿using System;

namespace LoopingConstructs
{
    internal class ForLoopDemo
    {
        static void Main()
        {
            int[] nums = { 34, 56, 45, 67, 89 };
            int sum = 0;

            for (int i = 0; i < 5; i++)
            {
                sum = sum + nums[i];
                Console.Write($"{sum}\t");
            }
        }
    }
}
