﻿using System;


namespace LoopingConstructs
{
    internal class DoWhileLoopDemo
    {
        static void Main()
        {
          
            int i = 5;
            do
            {
                Console.Write($"{i}\t");
                i++;
            } while (i < 5);
        }
    }
}
