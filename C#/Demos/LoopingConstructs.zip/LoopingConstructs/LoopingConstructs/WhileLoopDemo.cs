﻿using System;


namespace LoopingConstructs
{
    internal class WhileLoopDemo
    {
        static void Main()
        {
            int[] nums = { 34, 56, 45, 67, 89 };
            int sum = 0;
            int i = 0;
            while (i < 5)
            {
                sum=sum+nums[i];
                Console.Write($"{sum}\t");
                i++;
            }
        }
    }
}
