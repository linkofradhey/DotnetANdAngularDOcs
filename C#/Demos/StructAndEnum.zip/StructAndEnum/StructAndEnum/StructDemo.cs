﻿using System;


namespace StructAndEnum
{
    internal class StructDemo
    {
        static void Main()
        {
            Book book1 = new Book(123,"C#10.0","Scott");
            Console.WriteLine(book1.Display());

            Book book2 = new Book();
            book2.Isbn = book1.Isbn;
            Console.WriteLine(book2.Isbn);
        }
    }
}
