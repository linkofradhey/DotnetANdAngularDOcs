﻿using System;


namespace StructAndEnum
{
    internal struct Book
    {
        public int Isbn { get; set; }
        public string BookName { get; set; }
        public string AuthorName { get; set; }

        //default constructor
        public Book()
        {
            
        }

        public Book(int id,string name,string author)
        {
            this.Isbn= id;
            this.BookName = name;
            this.AuthorName = author;
        }

        public string Display()
        {
            return $"{this.Isbn}\t{this.BookName}\t{this.AuthorName}";
        }

    }
}
