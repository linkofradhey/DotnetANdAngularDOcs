﻿using System;


namespace StructAndEnum
{
    internal class Product
    {
        public int ProductCode { get; set; }
        public string  ProductName { get; set; }
        public Categories ProductCategory { get; set; }
    }

    enum Categories
    {
        FMCG=1,Gadgets=2,Outfits=3,Electronics=4
    }
}
