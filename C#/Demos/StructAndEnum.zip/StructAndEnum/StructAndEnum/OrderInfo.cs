﻿using System;


namespace StructAndEnum
{
    internal class OrderInfo
    {
        public int OrderId { get; set; }
        public DateTime OrderDate { get; set; }
        public OrderStatusCodes OrderStatus { get; set; }
    }

    enum OrderStatusCodes
    {
        Placed=100,InTransit=101,Delivered=102
    }
}
