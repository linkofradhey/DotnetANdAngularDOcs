﻿using System;


namespace StructAndEnum
{
    internal class EnumDemo
    {
        static void Main()
        {
            OrderInfo order1 = new OrderInfo { OrderId = 1, OrderDate = DateTime.Parse("22-09-2026"),OrderStatus=OrderStatusCodes.Placed };

            Console.WriteLine($"{order1.OrderId}\t{order1.OrderDate}\t{order1.OrderStatus}");

            // Console.WriteLine(OrderStatusCodes.Placed.GetHashCode());

            Console.WriteLine("Order Status are:");
            var status = Enum.GetNames(typeof(OrderStatusCodes));
            foreach (var item in status)
            {
                Console.WriteLine(item);
            }

            var member = Enum.GetName(typeof(OrderStatusCodes), 102);
            Console.WriteLine($"Member of constant 102 is {member}");


            Product product1 = new Product();
            product1.ProductCode = 100;
            product1.ProductName = "Shampoo";
            product1.ProductCategory = Categories.FMCG;

            Console.WriteLine($"{product1.ProductCode}\t{product1.ProductName}\t{product1.ProductCategory}");
        }
    }
}
