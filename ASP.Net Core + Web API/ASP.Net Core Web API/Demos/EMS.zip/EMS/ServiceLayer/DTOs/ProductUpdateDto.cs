﻿using System.ComponentModel.DataAnnotations;

namespace ServiceLayer.DTOs
{
    public class ProductUpdateDto
    {
        [Range(100, 1000)]
        [Required]
        public int ProductId { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 2)]
        public string? ProductName { get; set; }

        [StringLength(50, MinimumLength = 2)]
        public string? ProductCategory { get; set; }
        public double ListPrice { get; set; }
    }
}
