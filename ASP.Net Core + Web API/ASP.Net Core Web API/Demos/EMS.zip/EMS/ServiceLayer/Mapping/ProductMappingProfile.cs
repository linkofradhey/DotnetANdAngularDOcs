﻿using AutoMapper;
using DAL.Models;
using ServiceLayer.DTOs;

namespace ServiceLayer.Mapping
{
    public class ProductMappingProfile:Profile
    {
        public ProductMappingProfile()
        {
            //Entity=>Read DTO
            CreateMap<Product, ProductReadDto>();

            //Create DTO=>Entity
            CreateMap<ProductCreateDto, Product>();

            //Update DTO=>Entity
            CreateMap<ProductUpdateDto, Product>();
        }


    }
}
