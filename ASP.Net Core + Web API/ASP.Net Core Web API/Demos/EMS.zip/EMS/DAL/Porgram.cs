﻿using DAL.DataAccess;
using DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    internal class Porgram
    {
        static async Task Main()
        {
          //  ProductService productService = new ProductService();

          //  Product product1 = 
          //      new Product { ProductId = 100, ProductName = "Perfume", ProductCategory = "Cosmetic", ListPrice = 200 };
          //var result= await productService.AddProduct(product1);
          //  Console.WriteLine(result?"Product Added":"Error");
        }
    }
}
