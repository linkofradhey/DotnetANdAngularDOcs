﻿using DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DataAccess
{
    public class AdminInfoService : IAdminInfoService<AdminInfo>
    {
        private readonly ECommContext _dbContext;
        public AdminInfoService(ECommContext dbContext)
        {
            this._dbContext = dbContext;            
        }
        public async Task<bool> ValidateAdmin(AdminInfo entity)
        {
           
                var result =await _dbContext.AdminInfos.AnyAsync(admin => admin.EmailId.Equals(entity.EmailId) 
                && admin.Password.Equals(entity.Password) && admin.Role.Equals("Admin"));

                return result;
            
        }
    }
}
