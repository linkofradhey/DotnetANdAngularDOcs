﻿using DAL.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DataAccess
{
    public class ProductService : IProductService<Product>
    {
        private readonly ECommContext _dbContext;
        public ProductService(ECommContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<bool> AddProduct(Product newProduct)
        {
          
                if (newProduct != null)
                {
                _dbContext.Products.Add(newProduct);//Entity State:Unchaged=>Added
                    await _dbContext.SaveChangesAsync();//It will build t-sql (insert into Product..)
                    return  true;
                }
                else
                {
                    return false;
                }
            
        }
        public async Task<bool> RemoveProduct(int id)
         {
           
                var existingProduct = _dbContext.Products.Where(pro=>pro.ProductId.Equals(id)).FirstOrDefault();
                if (existingProduct != null)
                {
                    //dbContext.Products.Remove(existingProduct); //Entity State:Unchaged=>Deleted

                    //To apply soft delete, need to set true to IsDeleted column
                    existingProduct.IsDeleted = true;

                   await _dbContext.SaveChangesAsync();//It will build t-sql (delete from Product)
                    return true;
                }
                else
                {
                    return false;   
                }
            
         }
        public async Task<bool> UpdateProduct(Product updatedProduct)
        {
            
                var existingProduct = _dbContext.Products.Where(pro => pro.ProductId.Equals(updatedProduct.ProductId)).
                    FirstOrDefault();
                if (existingProduct != null)
                {
                    //EntityState:Unchanged=>Modified
                    existingProduct.ProductName= updatedProduct.ProductName;
                    existingProduct.ProductCategory= updatedProduct.ProductCategory;
                    existingProduct.ListPrice= updatedProduct.ListPrice;
                   await _dbContext.SaveChangesAsync();//It will build t-sql (update Product set..)
                    return true;
                }
                else
                {
                    return false;
                }
            
        }
        public async Task<IEnumerable<Product>> GetAllProducts()
        {
           
                //To disable query filter for admin
                //var products = await dbContext.Products.IgnoreQueryFilters().ToListAsync();

                var products = await _dbContext.Products. ToListAsync();
                return products;
            
        }
        public async Task<Product> SearchProductById(int id)
        {
            
                var productById =await _dbContext.Products.Where(pro => pro.ProductId.Equals(id)).FirstOrDefaultAsync();
                return productById;
            
        }
        public async Task<Product> SearchProductByName(string name)
        {
          
                var productByName =await _dbContext.Products.Where(pro => pro.ProductName.Equals(name)).FirstOrDefaultAsync();
               
                return productByName;
            
        }

        
        
    }
}
