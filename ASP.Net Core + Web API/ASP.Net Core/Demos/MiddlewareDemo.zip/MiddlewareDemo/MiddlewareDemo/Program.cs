var builder = WebApplication.CreateBuilder(args);

//To Register Dependencies and To Add/Configure Services

var app = builder.Build();
//To Start Adding/Configuring Middlewares

//How to add middleware conditionally based on Environment
if (builder.Environment.IsDevelopment())
{
    //middleware to enable exception page for developer
    app.UseDeveloperExceptionPage();
}

app.UseStaticFiles();

app.UseRouting();

//To Add in-line Custom-Middleware

//custom middleware-1
app.Use(async (context,next) =>
{
    await context.Response.WriteAsync("Incoming Request to Custom Middleware-1\n");
    await next();

    await context.Response.WriteAsync("Outgoing Response from Custom Middleware-1\n");
});

//custom middleware-2
app.Use(async (context, next) =>
{
    await context.Response.WriteAsync("Incoming Request to Custom Middleware-2\n");
    await next();

    await context.Response.WriteAsync("Outgoing Response from Custom Middleware-2\n");
});

//custom middleware-3
app.Use(async (context, next) =>
{
    await context.Response.WriteAsync("Incoming Request to Custom Middleware-3\n");
    await next();

    await context.Response.WriteAsync("Outgoing Response from Custom Middleware-3\n");
});

//Terminal EndPointpoint middleware

app.Run(async (context) =>{
    await context.Response.WriteAsync("Endpoint Middleware\n");
});
app.Run();
