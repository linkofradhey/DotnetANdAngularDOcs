using CustomMiddlewareDemo.CustomMiddleware;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

if (builder.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseStaticFiles();

//To Add Custom Middleware
app.UseMiddleware<RequestLoggerMiddleware>();

app.Run(async (context) =>
{
    await context.Response.WriteAsync("End Point Middleware");
});

app.Run();
