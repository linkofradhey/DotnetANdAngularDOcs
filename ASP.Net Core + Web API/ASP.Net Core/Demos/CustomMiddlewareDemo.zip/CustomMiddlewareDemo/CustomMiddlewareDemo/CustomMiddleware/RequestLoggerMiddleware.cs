﻿namespace CustomMiddlewareDemo.CustomMiddleware
{
    public class RequestLoggerMiddleware
    {
        private readonly RequestDelegate next;

        public RequestLoggerMiddleware(RequestDelegate _next)
        {
            this.next = _next;
        }

       public async Task InvokeAsync(HttpContext httpContext)
        {
            //Log Request Details
            var request = httpContext.Request;

            //form of message
            var logMessage = $"Request Time:{DateTime.Now} Http Method:{request.Method} PATH:{request.Path}\n";

            //write log message to log.txt file
            await File.AppendAllTextAsync("log.txt", logMessage);

            //call next middleware in the pipeline
            await next(httpContext);

            //Log Response
            var response = httpContext.Response;

            //form of message
            var logMessage2 = $"Response Time:{DateTime.Now} Http Status Code:{response.StatusCode} \n";

            //write log message to log.txt file
            await File.AppendAllTextAsync("log.txt", logMessage2);
        }

    }
}
