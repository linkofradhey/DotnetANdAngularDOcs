

var builder = WebApplication.CreateBuilder(args);

//To Access Configuration Settings
var settings = builder.Configuration["ConnectionStrings:MyConnection"];

var app = builder.Build();


//End-Point Middleware : 
app.Run(async (context)=>
{
    //await context.Response.WriteAsync($"{settings}");
    await context.Response.WriteAsync($"{builder.Configuration["AdminUser:Email"]}");
});

app.Run();