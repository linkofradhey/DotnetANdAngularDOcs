var builder = WebApplication.CreateBuilder(args);

//You can Register Dependencies and Add Services

var app = builder.Build();
//You can start adding/configuring your middlewares

app.MapGet("/", () => "Hello World!");

app.Run();
