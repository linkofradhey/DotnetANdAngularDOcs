﻿using DAL.DataAccess;
using DAL.Models;
class Program
{
    static void Main()
    {
        CustomerService customerService = new CustomerService();
        Console.Write("Please Enter 1.Add Customer 2.Delete Customer 3.Update Customer 4.Get All Customer 5.Search Customer By Name 6.Search Customer By Id:");
        string choice = Console.ReadLine();
        switch (choice)
        {
            case "1":
                Customer customer1 = new Customer { FirstName = "Smith", LastName = "Jhone", Email = "smith@gmail.com", City = "Mumbai", State = "MH", Phone = "456", Street = "M.G.Road", ZipCode = "564" };
               var isSaved= customerService.AddCustomer(customer1);
                Console.WriteLine(isSaved?"Customer Details Added Successfully":"Error");
                break;
            case "2":
                var custIdToDelete = 1447;
                var isDeleted=customerService.DeleteCustomer(custIdToDelete);
                Console.WriteLine(isDeleted ?"Customer is Deleted":"Error");
                break;
            case "3":
                Customer updatedCustomer = new Customer {CustomerId=1448, FirstName = "Smith123", LastName = "Jhone", Email = "smit123h@gmail.com", City = "Chennai", State = "TL", Phone = "56756", Street = "OMR", ZipCode = "564" };
               var isUpdated= customerService.UpdateCustomer(updatedCustomer);
                Console.WriteLine(isUpdated ?"Customer is Updated":"Error");
                break;

            case "4":
                var allCustomers= customerService.GetAllCustomers();
                foreach (var item in allCustomers)
                {
                    Console.WriteLine($"{item.FirstName}\t{item.LastName}\t{item.Email}");
                }
                break;
            case "5":
                var custByName = customerService.GetCustomerByFirstName("smith123");
                Console.WriteLine($"{custByName.CustomerId}\t{custByName.FirstName}\t{custByName.LastName}\t{custByName.Email}");
                break;
            case "6":
                var custById = customerService.GetCustomerById(1448);
                Console.WriteLine($"{custById.CustomerId}\t{custById.FirstName}\t{custById.LastName}\t{custById.Email}");

                break;
            default:
                Console.WriteLine("Invalid Choice");
                break;
        }
    }
}
