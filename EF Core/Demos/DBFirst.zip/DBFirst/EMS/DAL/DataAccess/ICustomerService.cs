﻿using System;
using System.Collections.Generic;
using System.Linq;



namespace DAL.DataAccess
{
    public interface ICustomerService<T>
    {
        bool AddCustomer(T newCustomer);

        bool DeleteCustomer(int id);

        bool UpdateCustomer(T updatedCustomer);

        T GetCustomerById(int id);

        T GetCustomerByFirstName(string firstName);

        IEnumerable<T> GetAllCustomers();

    }
}
