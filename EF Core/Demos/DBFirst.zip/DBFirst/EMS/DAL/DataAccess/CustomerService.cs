﻿using DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DataAccess
{
    public class CustomerService : ICustomerService<Customer>
    {
        public bool AddCustomer(Customer newCustomer)
        {
            using (EcommContext dbContext=new EcommContext())
            {
                dbContext.Customers.Add(newCustomer); //It changes entity state from UnChanged to Added
                dbContext.SaveChanges();//It will observe current state on an entity and build t-slq statement (insert into customers..)
                return true;
            }
        }

        public bool DeleteCustomer(int id)
        {
            using (EcommContext DbContext=new EcommContext())
            {
                var existingCustomer = DbContext.Customers.Where(cust => cust.CustomerId.Equals(id)).FirstOrDefault();
                DbContext.Customers.Remove(existingCustomer);//it will change current state of an entity from unchanged to deleted
                DbContext.SaveChanges();//it will observe current state of an entity and build t-sql (delete from customer..)
                return true;
            }
        }

        public bool UpdateCustomer(Customer updatedCustomer)
        {
            using (EcommContext dbContext=new EcommContext())
            {
                var exisitingCustomer = dbContext.Customers.Where(cust => cust.CustomerId.Equals(updatedCustomer.CustomerId)).FirstOrDefault();
                if (exisitingCustomer != null)
                {
                    //It will change current entity state from unchanged to modified
                    exisitingCustomer.FirstName= updatedCustomer.FirstName;
                    exisitingCustomer.LastName= updatedCustomer.LastName;
                    exisitingCustomer.Email= updatedCustomer.Email;
                    exisitingCustomer.City= updatedCustomer.City;
                    exisitingCustomer.Phone= updatedCustomer.Phone;
                    exisitingCustomer.Street= updatedCustomer.Street;
                    exisitingCustomer.State= updatedCustomer.State;
                    dbContext.SaveChanges();//it will build t-sql (update customer set....)
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public IEnumerable<Customer> GetAllCustomers()
        {
            using (EcommContext dbContext = new EcommContext())
            {
                var allCustomers = dbContext.Customers.ToList();
                return allCustomers;
            }
        }

        public Customer GetCustomerByFirstName(string firstName)
        {
            using (EcommContext dbContext = new EcommContext())
            {
                var custByName = dbContext.Customers.Where(cust=>cust.FirstName.Equals(firstName)).FirstOrDefault();
                return custByName;
            }
        }

        public Customer GetCustomerById(int id)
        {
            using (EcommContext dbContext = new EcommContext())
            {
                var custById = dbContext.Customers.Where(cust => cust.CustomerId.Equals(id)).FirstOrDefault();
                return custById;
            }
        }

       
    }
}
