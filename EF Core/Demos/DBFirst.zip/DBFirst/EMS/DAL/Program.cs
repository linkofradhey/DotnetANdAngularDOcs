﻿using DAL.DataAccess;
using DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;


namespace DAL
{
    internal class Program
    {
        static void Main()
        {
            CustomerService customerService= new CustomerService();
            Customer customer1 = new Customer { FirstName = "Scott", LastName = "Jhone", Email = "scott@gmail.com", City = "Pune", State = "MH", Phone = "45454", Street = "M.G.Road", ZipCode = "3453" };
            customerService.AddCustomer(customer1);
            Console.WriteLine("Customer Added Successfully");
        }
    }
}
