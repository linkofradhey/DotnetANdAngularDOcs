﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class OrderDetailsWithOrderItemsAndCustomer
{
    public int CustomerId { get; set; }

    public string FirstName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string? City { get; set; }

    public int OrderId { get; set; }

    public DateOnly OrderDate { get; set; }

    public int ItemId { get; set; }

    public decimal ListPrice { get; set; }

    public int Quantity { get; set; }
}
