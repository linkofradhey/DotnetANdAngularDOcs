﻿using System;
using System.Collections.Generic;

namespace DAL.Models;

public partial class Part
{
    public int PartId { get; set; }

    public string? PartName { get; set; }
}
