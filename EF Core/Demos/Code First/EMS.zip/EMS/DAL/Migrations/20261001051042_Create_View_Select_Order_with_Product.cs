﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DAL.Migrations
{
    /// <inheritdoc />
    public partial class Create_View_Select_Order_with_Product : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var tsql = @"CREATE VIEW Select_OrderDetails_With_Product
                        AS
                        Select O.OrderId,O.OrderDate,O.OrderAmount,O.EmailId,
                        P.ProductId,P.ProductName,P.ProductCategory from [Order] O
                        INNER JOIN
                        Product P
                        ON
                        O.ProductId=P.ProductId";
            migrationBuilder.Sql(tsql);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            var tsql = @"DROP VIEW Select_OrderDetails_With_Product";
            migrationBuilder.Sql(tsql);
        }
    }
}
