﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace DAL.Migrations
{
    /// <inheritdoc />
    public partial class Create_SP_Add_Product : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            var tsql = @"CREATE PROCEDURE usp_AddProduct
                        @ProductId INT,
                        @ProductName nvarchar(50),
                        @ProductCategory nvarchar(50),
                        @ListPrice float
                        AS
                        BEGIN
	                        INSERT INTO [Product] VALUES(@ProductId,@ProductName,@ProductCategory,@ListPrice)
                        END";
            migrationBuilder.Sql(tsql);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            var tsql = @"DROP PROCEDURE usp_AddProduct";
            migrationBuilder.Sql(tsql);
        }
    }
}
