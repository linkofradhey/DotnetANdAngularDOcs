﻿using DAL.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DataAccess
{
    public class ProductService : IProductService<Product>
    {
        public async Task<bool> AddProduct(Product newProduct)
        {
            using (ECommContext dbContext=new ECommContext())
            {
                if (newProduct != null)
                {
                    dbContext.Products.Add(newProduct);//Entity State:Unchaged=>Added
                    await  dbContext.SaveChangesAsync();//It will build t-sql (insert into Product..)
                    return  true;
                }
                else
                {
                    return false;
                }
            }
        }
        public async Task<bool> RemoveProduct(int id)
         {
            using (ECommContext dbContext=new ECommContext())
            {
                var existingProduct = dbContext.Products.Where(pro=>pro.ProductId.Equals(id)).FirstOrDefault();
                if (existingProduct != null)
                {
                    //dbContext.Products.Remove(existingProduct); //Entity State:Unchaged=>Deleted

                    //To apply soft delete, need to set true to IsDeleted column
                    existingProduct.IsDeleted = true;

                   await dbContext.SaveChangesAsync();//It will build t-sql (delete from Product)
                    return true;
                }
                else
                {
                    return false;   
                }
            }
         }
        public async Task<bool> UpdateProduct(Product updatedProduct)
        {
            using (ECommContext dbContext = new ECommContext())
            {
                var existingProduct = dbContext.Products.Where(pro => pro.ProductId.Equals(updatedProduct.ProductId)).
                    FirstOrDefault();
                if (existingProduct != null)
                {
                    //EntityState:Unchanged=>Modified
                    existingProduct.ProductName= updatedProduct.ProductName;
                    existingProduct.ProductCategory= updatedProduct.ProductCategory;
                    existingProduct.ListPrice= updatedProduct.ListPrice;
                   await dbContext.SaveChangesAsync();//It will build t-sql (update Product set..)
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public async Task<IEnumerable<Product>> GetAllProducts()
        {
            using (ECommContext dbContext=new ECommContext())
            {
                //To disable query filter for admin
                //var products = await dbContext.Products.IgnoreQueryFilters().ToListAsync();

                var products = await dbContext.Products. ToListAsync();
                return products;
            }
        }
        public async Task<Product> SearchProductById(int id)
        {
            using (ECommContext dbContext = new ECommContext())
            {
                var productById =await dbContext.Products.Where(pro => pro.ProductId.Equals(id)).FirstOrDefaultAsync();
                return productById;
            }
        }
        public async Task<Product> SearchProductByName(string name)
        {
            using (ECommContext dbContext = new ECommContext())
            {
                var productByName =await dbContext.Products.Where(pro => pro.ProductName.Equals(name)).FirstOrDefaultAsync();
               
                return productByName;
            }
        }

        public async Task<bool> SaveProduct(Product newProduct)
        {
            using (ECommContext dbContext=new ECommContext())
            {
              var result= await dbContext.Database.ExecuteSqlRawAsync("usp_AddProduct @ProductId,@ProductName,@ProductCategory,@ListPrice",
                    new SqlParameter("@ProductId",newProduct.ProductId),new SqlParameter("@ProductName",newProduct.ProductName),
                    new SqlParameter("@ProductCategory",newProduct.ProductCategory),new SqlParameter("@ListPrice",newProduct.ListPrice));
                if (result > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        
    }
}
