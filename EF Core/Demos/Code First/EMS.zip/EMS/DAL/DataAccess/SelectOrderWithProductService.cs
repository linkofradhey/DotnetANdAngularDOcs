﻿using DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DataAccess
{
    public class SelectOrderWithProductService : ISelectOrderWithProductService<Select_Order_With_Product>
    {
        public IEnumerable<Select_Order_With_Product> GetAllOrdersWithProducts()
        {
            using (ECommContext dbContext=new ECommContext())
            {
                var orderDetailsWithProduct = dbContext.DisplayOrderWithProduct.ToList();
                return orderDetailsWithProduct;
            }
        }
        public Select_Order_With_Product GetOrderByProductName(string name)
        {
            using (ECommContext dbContext = new ECommContext())
            {
                var getOrderByProductName = dbContext.DisplayOrderWithProduct.Where(pro=>pro.ProductName.Equals(name)).FirstOrDefault();
                return getOrderByProductName;
             }
        }
        public Select_Order_With_Product GetOrderByProductId(int productId)
        {
            using (ECommContext dbContext = new ECommContext())
            {
                var getOrderByProductId = dbContext.DisplayOrderWithProduct.Where(pro => pro.ProductId.Equals(productId)).FirstOrDefault();
                return getOrderByProductId;
            }
        }
        public Select_Order_With_Product GetOrderWithOrderId(int id)
        {
            using (ECommContext dbContext = new ECommContext())
            {
                var getOrderByOrderId = dbContext.DisplayOrderWithProduct.Where(pro => pro.OrderId.Equals(id)).FirstOrDefault();
                return getOrderByOrderId;
            }
        }
    }
}
