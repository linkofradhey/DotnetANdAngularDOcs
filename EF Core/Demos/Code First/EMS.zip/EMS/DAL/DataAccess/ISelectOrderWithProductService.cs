﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DataAccess
{
    public interface ISelectOrderWithProductService<T>
    {
        IEnumerable<T> GetAllOrdersWithProducts();

        T GetOrderWithOrderId(int id);

        T GetOrderByProductId(int productId);

        T GetOrderByProductName(string name);
    }
}
