﻿using DAL.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DataAccess
{
    public class AdminInfoService : IAdminInfoService<AdminInfo>
    {
        public async Task<bool> ValidateAdmin(AdminInfo entity)
        {
            using (ECommContext dbContext=new ECommContext())
            {
                var result =await dbContext.AdminInfos.AnyAsync(admin => admin.EmailId.Equals(entity.EmailId) 
                && admin.Password.Equals(entity.Password) && admin.Role.Equals("Admin"));

                return result;
            }
        }
    }
}
