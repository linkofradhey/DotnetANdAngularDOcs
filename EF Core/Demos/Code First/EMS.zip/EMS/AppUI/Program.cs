﻿using DAL.DataAccess;
using DAL.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppUI
{
    internal class Program
    {
        static async Task Main()
        {
            AdminInfoService adminInfoService = new AdminInfoService();

            Console.WriteLine($"Enter Email Id for Admin:");
            var email = Console.ReadLine();

            Console.WriteLine($"Enter Password for Admin:");
            var password = Console.ReadLine();

            AdminInfo adminInfo = new AdminInfo { EmailId = email, Password = password, Role = "Admin" };
            if (await adminInfoService.ValidateAdmin(adminInfo))
            {
                Console.Write("Enter 1.To Add a Product 2.To Delete a Product 3.To Update a Product 4.To Display All Products 5.To Search Product ByI Id 6.To Search Product By Name:");
                var choice = Console.ReadLine();
                ProductService productService = new ProductService();
                switch (choice)
                {
                    case "1":
                        Product product1 =
                        new Product { ProductId = 104, ProductName = "Cream", ProductCategory = "Cosmetics", ListPrice = 200 };
                        var isSaved= await productService.AddProduct(product1);
                        //var isSaved =await productService.SaveProduct(product1);
                        Console.WriteLine(isSaved ? "Product is Added Successfully" : "Error");
                        break;
                    case "2":
                        var productIdToDelete = 102;
                        var isDeleted =await productService.RemoveProduct(productIdToDelete);
                        Console.WriteLine(isDeleted ? "Product is Deleted" : "Error");
                        break;
                    case "3":
                        Product productToUpdate =
                        new Product { ProductId = 101, ProductName = "Shampoo", ProductCategory = "FMCG", ListPrice = 10 };
                        var isUpdated = await productService.UpdateProduct(productToUpdate);
                        Console.WriteLine(isUpdated ? "Product is Updated" : "Error");
                        break;
                    case "4":
                        var products = await productService.GetAllProducts();
                        foreach (var product in products)
                        {
                            Console.WriteLine($"{product.ProductId}\t{product.ProductName}\t{product.ProductCategory}\t{product.ListPrice}");
                        }
                        break;
                    case "5":
                        var productById =await productService.SearchProductById(101);
                        Console.WriteLine($"{productById.ProductId}\t{productById.ProductName}\t{productById.ProductCategory}\t{productById.ListPrice}");
                        break;
                    case "6":
                        var productByName =await productService.SearchProductByName("Shampoo");
                        Console.WriteLine($"{productByName.ProductId}\t{productByName.ProductName}\t{productByName.ProductCategory}\t{productByName.ListPrice}");
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Incorrect Email Id or Password");
            }
        }
        
    }
}
