﻿using DAL.DataAccess;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppUI
{
    internal class InvokeView
    {
        static void Main()
        {
            SelectOrderWithProductService selectOrderWithProductService = new SelectOrderWithProductService();
            Console.Write($"Enter 1.To Display All Orders with Product 2.Display Order with Order Id 3.Display Order with ProductId 4.Display Order With Product Name:");
            string choice = Console.ReadLine();
            switch (choice)
            {
                case "1":
                   var getAll= selectOrderWithProductService.GetAllOrdersWithProducts();
                    foreach (var item in getAll)
                    {
                        Console.WriteLine($"{item.OrderId}\t{item.OrderDate}\t{item.OrderAmount}\t{item.ProductId}\t{item.ProductName}\t{item.ProductCategory}");
                    }
                    break;
                case "2":
                    var orderId = 1;
                    var getByOrderId = selectOrderWithProductService.GetOrderWithOrderId(orderId);
                    Console.WriteLine($"{getByOrderId.OrderId}\t{getByOrderId.OrderDate}\t{getByOrderId.OrderAmount}\t{getByOrderId.ProductId}\t{getByOrderId.ProductName}\t{getByOrderId.ProductCategory}");
                    break;
                case "3":
                    var productId = 100;
                    var getByProductId = selectOrderWithProductService.GetOrderByProductId(productId);
                    Console.WriteLine($"{getByProductId.OrderId}\t{getByProductId.OrderDate}\t{getByProductId.OrderAmount}\t{getByProductId.ProductId}\t{getByProductId.ProductName}\t{getByProductId.ProductCategory}");
                    break;
                case "4":
                    var productName = "Perfume";
                    var getByProductName = selectOrderWithProductService.GetOrderByProductName(productName);
                    Console.WriteLine($"{getByProductName.OrderId}\t{getByProductName.OrderDate}\t{getByProductName.OrderAmount}\t{getByProductName.ProductId}\t{getByProductName.ProductName}\t{getByProductName.ProductCategory}");
                   break;
                default:
                    Console.WriteLine("Invalid Choice");
                    break;

            }
        }
    }
}
