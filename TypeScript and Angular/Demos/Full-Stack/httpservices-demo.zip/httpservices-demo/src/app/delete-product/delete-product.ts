import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductService } from '../services/product.service'; 
import { RouterModule,Router } from '@angular/router';
import { product } from '../models/product.model';
import { ActivatedRoute } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';
@Component({
  imports: [CommonModule,RouterModule],
  selector: 'app-delete-product',
  styleUrl: './delete-product.css',
  templateUrl: './delete-product.html',
})
export class DeleteProduct {
  constructor(private productService:ProductService,private router:ActivatedRoute,private route:Router, private cd:ChangeDetectorRef){}

    product?:product;
    ngOnInit(){
    const id=Number( this.router.snapshot.paramMap.get('id'));
    this.productService.getById(id).subscribe({
      next: (data) => {
        console.log(data);
        this.product = data;
        this.cd.detectChanges(); //FORCE UI UPDATE
      },
      error: (err) => console.error(err)
    });
}

deleteProduct(){
  const id=Number( this.router.snapshot.paramMap.get('id'));
  console.log(this.product);
  this.productService.deleteProduct(id).subscribe({
    next:()=>{
      console.log("Product Deleted");
      this.route.navigate(['/productlist']);
    },error:(err)=>{
      console.error("delete failed",err);
    }
  });
 }

}
