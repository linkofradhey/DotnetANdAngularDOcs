import { ChangeDetectorRef, Component } from '@angular/core';
import { ProductService } from '../services/product.service';
import { product } from '../models/product.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule,Router } from '@angular/router';
@Component({
  imports: [CommonModule,FormsModule,RouterModule],
  selector: 'app-product-list',
  styleUrl: './product-list.css',
  templateUrl: './product-list.html',
})
export class ProductList {
  constructor(private productService:ProductService,private router:Router,private cd:ChangeDetectorRef){
    this.loadProducts();
  }

products:product[]=[];

  loadProducts(){
    //this.productService.getAllProducts().subscribe(data=> this.products=data);

   this.productService.getAllProducts().subscribe({
      next:(res)=>{      
          this.products=res;
          this.cd.detectChanges();
        },
        error:(err)=>{
          console.log(err);
        }
    });

  }

  logout(){
    localStorage.removeItem('token');
    this.router.navigate(['/']);
  }
}
