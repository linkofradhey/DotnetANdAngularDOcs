import { Routes } from '@angular/router';
import { AdminLogin } from './admin-login/admin-login';
import { ProductList } from './product-list/product-list';
import { AddProduct } from './add-product/add-product';
import { DeleteProduct } from './delete-product/delete-product';
import { UpdateProduct } from './update-product/update-product';
import { ProductByid } from './product-byid/product-byid';
import { AuthGuard } from './auth.guards';

export const routes: Routes = [
    {path:'',component:AdminLogin},
    {path:'adminlogin',component:AdminLogin},
    {path:'productlist',component:ProductList},
    {path:'addproduct',component:AddProduct,canActivate:[AuthGuard]},
    {path:'updateproduct/:id',component:UpdateProduct,canActivate:[AuthGuard]},
    {path:'deleteproduct/:id',component:DeleteProduct,canActivate:[AuthGuard]},
    {path:'getbyid/:id',component:ProductByid}
];
