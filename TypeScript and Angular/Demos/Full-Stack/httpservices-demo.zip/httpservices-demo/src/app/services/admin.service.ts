import {Injectable} from "@angular/core";
import{HttpClient} from "@angular/common/http";
import{AdminInfo} from "../models/admin.model";
import{Observable} from "rxjs"

@Injectable({
    providedIn:"root"
})
export class AdminService{

    private baseUrl="http://localhost:5049/api/v1.0/AdminUser";

    constructor(private http:HttpClient){}

    validateAdmin(admin:AdminInfo):Observable<any>{
        return this.http.post(`${this.baseUrl}/ValidateAdmin`,admin, {responseType:'text'});
    }
}