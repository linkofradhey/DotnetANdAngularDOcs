
import { Injectable } from "@angular/core";
import { HttpClient,HttpHeaders } from "@angular/common/http";
import { product } from "../models/product.model";
import { Observable } from "rxjs";

@Injectable({
    providedIn:"root"
})
export class ProductService{

    private baseUrl="http://localhost:5049/api/v2.0/ProductInfo"

    constructor(private http:HttpClient){}

    getAllProducts():Observable<product[]>{
        return this.http.get<product[]>(`${this.baseUrl}/GetAll`);
    }

    getById(id:number):Observable<product>{
        return this.http.get<product>(`${this.baseUrl}/GetById/${id}`);
    }

    addProduct(product:product):Observable<product>{
        const token=localStorage.getItem('token');
        const headers=new HttpHeaders().set('Authorization',`Bearer ${token}`);
        return this.http.post<product>(`${this.baseUrl}/AddProduct`,product,{headers});
    }

    deleteProduct(id:number):Observable<any>{
          const token=localStorage.getItem('token');
        const headers=new HttpHeaders().set('Authorization',`Bearer ${token}`);
        return this.http.delete(`${this.baseUrl}/DeleteProduct/${id}`,{headers});
    
    }

    updateProduct(product:product):Observable<product>{
        const token=localStorage.getItem('token');
        const headers=new HttpHeaders().set('Authorization',`Bearer ${token}`);
        return this.http.put<product>(`${this.baseUrl}/UpdateProduct`,product,{headers});
    }
}