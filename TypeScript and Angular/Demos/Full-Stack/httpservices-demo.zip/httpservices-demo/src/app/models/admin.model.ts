export interface AdminInfo{
    emailId:string;
    password:string;
    role:string;
}