export interface product{
    productId:number;
    productName:string;
    productCategory:string;
    listPrice:number;
}