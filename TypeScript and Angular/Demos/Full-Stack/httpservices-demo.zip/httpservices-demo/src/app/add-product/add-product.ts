import { Component } from '@angular/core';
import { ProductService } from '../services/product.service';
import { product } from '../models/product.model';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router,RouterModule } from '@angular/router';
@Component({
  imports: [CommonModule,FormsModule,RouterModule],
  selector: 'app-add-product',
  styleUrl: './add-product.css',
  templateUrl: './add-product.html',
})
export class AddProduct {
  constructor(private productService:ProductService,private router:Router){}

   product:product={
    productId:0,
    productName:'',
    productCategory:'',
    listPrice:0
  }
 addNewProduct(){
    console.log(this.product);
    this.productService.addProduct(this.product).subscribe(
      {
        next:(res)=>{
          console.log("Product Added Successfully",res);
          this.router.navigate(['/productlist']);
        },error:(err)=>{
          console.error("Error adding product",err);
        }
      }
    );
   
  }

}
