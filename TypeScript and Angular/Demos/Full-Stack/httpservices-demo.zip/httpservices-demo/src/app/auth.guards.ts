import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate,GuardResult,MaybeAsync,Router, RouterStateSnapshot } from "@angular/router";


export class AuthGuard implements CanActivate{
    constructor(private router:Router){}

    canActivate():boolean{
        const token=localStorage.getItem('token');
        if(token){
            return true;
        }else{
            //No token:redirect to login
            this.router.navigate(['/']);
            
            return false;
        }
    }
        
    
}