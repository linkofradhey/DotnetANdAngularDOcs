import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ProductService } from '../services/product.service'; 
import { RouterModule,Router } from '@angular/router';
import { product } from '../models/product.model'; 
import { ActivatedRoute } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';
@Component({
  imports: [CommonModule,FormsModule,RouterModule],
  selector: 'app-update-product',
  styleUrl: './update-product.css',
  templateUrl: './update-product.html',
})
export class UpdateProduct {
  constructor(private productService:ProductService,private router:ActivatedRoute,private route:Router, private cd:ChangeDetectorRef){}

  product:product={
    productId:0,
    productName:'',
    productCategory:'',
    listPrice:0
   };

   ngOnInit(){
    const id=Number( this.router.snapshot.paramMap.get('id'));
    this.productService.getById(id).subscribe({
      next: (data) => {
        console.log(data);
        this.product = data;
        this.cd.detectChanges(); //FORCE UI UPDATE
      },
      error: (err) => console.error(err)
    });

  }

   updateProduct(){
    this.productService.updateProduct(this.product).subscribe({
      next:(res)=>{
        console.log("Product Updated",res);
        this.route.navigate(['/productlist']);
      }
    });
  }

}
