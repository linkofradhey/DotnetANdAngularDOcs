import { Component } from '@angular/core';
import { AdminService } from '../services/admin.service';
import { AdminInfo } from '../models/admin.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  imports: [CommonModule,FormsModule],
  selector: 'app-admin-login',
  styleUrl: './admin-login.css',
  templateUrl: './admin-login.html',
})
export class AdminLogin {

  constructor(private adminService:AdminService,private router:Router){}

  admin:AdminInfo={
    emailId:'',
    password:'',
    role:''
  }

  errorMessage="";

  onLogin(){
    this.adminService.validateAdmin(this.admin).subscribe(
      {
        //send a value to subscriber
        next:(res)=>{
          localStorage.setItem('token',res);
          alert("LoggedIn");
          this.router.navigate(['productlist']);
        },
        error:(err)=>{
          this.errorMessage="Invalid Credentials";
          console.log(err);
        }
      }
    );
  }
}
