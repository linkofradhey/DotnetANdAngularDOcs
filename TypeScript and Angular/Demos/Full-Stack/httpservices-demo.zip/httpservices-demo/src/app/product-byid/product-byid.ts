import { Component } from '@angular/core';
import { ProductService } from '../services/product.service';
import { product } from '../models/product.model';
import { CommonModule } from '@angular/common';
import { Router,RouterModule } from '@angular/router';
import { ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
@Component({
  imports: [CommonModule,RouterModule,],
  selector: 'app-product-byid',
  styleUrl: './product-byid.css',
  templateUrl: './product-byid.html',
})
export class ProductByid {
  constructor(private productService:ProductService,private router:ActivatedRoute,private cd:ChangeDetectorRef){}

    product?:product;
ngOnInit(){
    const id=Number( this.router.snapshot.paramMap.get('id'));
    this.productService.getById(id).subscribe({
      next: (data) => {
        console.log(data);
        this.product = data;
        this.cd.detectChanges(); //FORCE UI UPDATE
      },
      error: (err) => console.error(err)
    });

  }
}
