
//service injector
interface ILogger{
    log(message:string):void;
}

//service provider
class ConsoleLogger implements ILogger{
    log(message: string): void {
        console.log(message);
    }
}

//Service provider
class FileLogger implements ILogger{
log(message: string): void {
        console.log("File",message);
    }
}

//client
class UserService{
    constructor( private logger:ILogger){}

    getUser(){
        this.logger.log("Fetching User..");
    }
}


const logger1=new ConsoleLogger();
const userService1=new UserService(logger1);
userService1.getUser();