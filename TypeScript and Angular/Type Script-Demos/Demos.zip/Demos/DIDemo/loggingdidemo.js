"use strict";
//service provider
class ConsoleLogger {
    log(message) {
        console.log(message);
    }
}
//Service provider
class FileLogger {
    log(message) {
        console.log("File", message);
    }
}
//client
class UserService {
    logger;
    constructor(logger) {
        this.logger = logger;
    }
    getUser() {
        this.logger.log("Fetching User..");
    }
}
const logger1 = new ConsoleLogger();
const userService1 = new UserService(logger1);
userService1.getUser();
