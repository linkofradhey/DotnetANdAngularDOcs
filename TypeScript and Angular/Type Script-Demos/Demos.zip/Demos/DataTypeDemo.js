"use strict";
//TypeScript Basics (data types + template literals)
let studentName = "Amit";
let age = 22;
let isPlaced = false;
let message = `Student ${studentName} is ${age} year old.Placement Status:${isPlaced}`;
console.log(message);
