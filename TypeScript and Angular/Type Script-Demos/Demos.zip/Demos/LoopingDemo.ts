
//for 
console.log("==========printing numbers using for loop===");
for (let index = 0; index < 10; index++) {
    console.log(index);
    
}

console.log("======printing array values using for loops");
let courses:string[]=["HTML","CSS","TypeScript"];

for (let index = 0; index < courses.length; index++) {
    const element = courses[index];
    console.log(element);
    
}

console.log("====printing array values using for of===");
for (const element of courses) {
    console.log(element);
}