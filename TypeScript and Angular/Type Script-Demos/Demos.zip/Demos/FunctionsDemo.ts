//Normal Function

function calculateSalary(basicSalary:number,bonus?:number):number{
    return basicSalary+(bonus || 0);
}

console.log(calculateSalary(200000));
console.log(calculateSalary(200000,5000));

//Arrow Function
const greet=(name:string):string=>{
    return `Hello ${name}`;
}

console.log(greet("Scott"));