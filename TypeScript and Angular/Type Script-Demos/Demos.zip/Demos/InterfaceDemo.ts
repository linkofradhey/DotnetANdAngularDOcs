//interface for data modeling

interface Product{
    id:number;
    name:string;
    price:number
}

let product1:Product={
    id:100,
    name:"Laptop",
    price:30000
}

console.log(`${product1.id}\t${product1.name}\t${product1.price}`);