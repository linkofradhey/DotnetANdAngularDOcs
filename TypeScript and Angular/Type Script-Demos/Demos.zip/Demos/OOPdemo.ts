//base class
class Employee{
    constructor(public name:string,private salary:number){}

    getSalary():number{
        return this.salary;
    }

    setSalary(amount:number){
        this.salary=amount;
    }
}

//inheritance
class Manager extends Employee{
    constructor(name:string,salary:number,public teamSize:number){
        super(name,salary);
    }

    //method overriding
    getSalary(): number {
        return super.getSalary()+10000;
    }
}

let emp=new Manager("Sachin",200000,10);
console.log(emp.getSalary());