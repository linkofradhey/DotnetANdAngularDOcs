//It contains business login: to add and to remove product from list

import { Product } from "./product.model";

let products:Product[]=[
    {id:100,name:"Laptop",price:30000},
    {id:101,name:"Mobile",price:20000}
];

//Funtion-1: To Add a product
export function addProduct(newProduct:Product):void{
    products.push(newProduct);
    console.log("Product is Added Successfully!");
}

//Function-2:To Remove a Product by id
export function removeProduct(id:number):void{
    const index=products.findIndex(p=>p.id===id);
    if(index!==-1){
        const removeProduct=products.splice(index,1);
        console.log("Product removed:",removeProduct[0].name);
    }else{
        console.log("Product Not Found");
    }
}

//Function-3:Return all the products
export function getProducts():Product[]{
    return products;
}