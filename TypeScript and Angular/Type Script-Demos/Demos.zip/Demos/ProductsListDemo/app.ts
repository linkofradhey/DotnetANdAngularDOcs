import { Product } from "./product.model";
import { addProduct,removeProduct,getProducts } from "./product.service";

console.log("Products in the List:");
for (const product of getProducts()) {
    console.log(`${product.id}\t${product.name}\t${product.price}`);
}

//Add new Product
let product1:Product={
    id:102,
    name:"headphone",
    price:800
}
addProduct(product1);

console.log("after adding new product into the list");
for (const product of getProducts()) {
    console.log(`${product.id}\t${product.name}\t${product.price}`);
}

//Remove a Product
removeProduct(101);
console.log("After removing a product with id 101");
for (const product of getProducts()) {
    console.log(`${product.id}\t${product.name}\t${product.price}`);
}