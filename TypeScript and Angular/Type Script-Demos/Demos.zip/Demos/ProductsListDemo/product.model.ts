//interface for data Modeling
export interface Product{
 id:Number,
 name:string,
 price:number
}
