//To declare interface for response

interface ApiResponse<T>{
    data:T;
    success:boolean;
}

let response:ApiResponse<number>={
    data:100,
    success:true
};

console.log(response);

