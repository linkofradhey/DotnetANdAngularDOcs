
//importing from modules
import { getStudentName,course } from "./studentUtil";

//using imported members
console.log(getStudentName("Sachin"));
console.log(course);

//To compile and run this project
//1.open terminal and get inside this project
//2.npx tsc
//3.after executing above command you will get /dist folder
//4.node dist/app.js