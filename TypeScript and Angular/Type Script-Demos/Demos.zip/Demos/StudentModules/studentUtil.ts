
//Export a function
export function getStudentName(name:string):string{
    return `Student name is ${name}`;
}

//Export variable
export const course="Full Stack Development";

export class Employee{}