"use strict";
//How to declare and use Generic class
class DataStore {
    items = [];
    add(item) {
        this.items.push(item);
    }
    getAll() {
        return this.items;
    }
}
let store1 = new DataStore();
store1.add(101);
store1.add(102);
store1.add(103);
var elements = store1.getAll();
for (const element of elements) {
    console.log(element);
}
