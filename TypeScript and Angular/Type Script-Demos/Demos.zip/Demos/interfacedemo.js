"use strict";
//interface for data modeling
let product1 = {
    id: 100,
    name: "Laptop",
    price: 30000
};
console.log(`${product1.id}\t${product1.name}\t${product1.price}`);
