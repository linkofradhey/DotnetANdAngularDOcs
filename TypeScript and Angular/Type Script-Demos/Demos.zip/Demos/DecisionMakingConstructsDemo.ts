//Decision Making Construct

function PrintGrade(marks:number):string{
    if(marks>=90){
        return "Grade A";
    }else if(marks>=60){
        return "Grade B"
    }else if(marks>=50){
        return "Grade C"
    }else{
        return "Failed";
    }
}

let marks=75;
let result:string=PrintGrade(marks);
console.log(result);

//Switch-Case
function PrintDayName(dayNumber:number):void{
    switch(dayNumber){
        case 1: console.log("Monday");
        break;
        case 2: console.log("Tuesday");
        break;
        case 3: console.log("Wednesday");
        break;
        case 4: console.log("Thursday");
        break;
        default:console.log("Invalid day number");
    }
}

let day:number=3;
PrintDayName(day);