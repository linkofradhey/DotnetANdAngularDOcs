"use strict";
//base class
class Employee {
    name;
    salary;
    constructor(name, salary) {
        this.name = name;
        this.salary = salary;
    }
    getSalary() {
        return this.salary;
    }
    setSalary(amount) {
        this.salary = amount;
    }
}
//inheritance
class Manager extends Employee {
    teamSize;
    constructor(name, salary, teamSize) {
        super(name, salary);
        this.teamSize = teamSize;
    }
    //method overriding
    getSalary() {
        return super.getSalary() + 10000;
    }
}
let emp = new Manager("Sachin", 200000, 10);
console.log(emp.getSalary());
