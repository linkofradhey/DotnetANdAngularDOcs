//Create Decorator
function Logger(constructor:Function){
    console.log("Logging...");
    console.log(constructor);
}

//Use decorator

@Logger
class Person{
    name:string="Sachin";
    constructor(){
        console.log("Person Object Created");
    }
}

const p1=new Person();