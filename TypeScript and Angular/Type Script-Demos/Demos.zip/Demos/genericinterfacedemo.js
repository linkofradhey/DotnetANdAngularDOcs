"use strict";
//To declare interface for data modeling
let response = {
    data: 100,
    success: true
};
console.log(response);
