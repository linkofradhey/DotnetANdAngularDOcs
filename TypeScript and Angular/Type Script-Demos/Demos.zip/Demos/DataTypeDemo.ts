//TypeScript Basics (data types + template literals)

let studentName:string="Amit";
let age:number=22;
let isPlaced=false;

let message:string=`Student ${studentName} is ${age} year old.Placement Status:${isPlaced}`;

console.log(message);