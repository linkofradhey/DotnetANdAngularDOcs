//How to declare and use Generic class

class DataStore<T>{

    private items:T[]=[];

    add(item:T){
        this.items.push(item);
    }

    getAll():T[]{
        return this.items;
    }
}

let store1=new DataStore<number>();
store1.add(101);
store1.add(102);
store1.add(103);

var elements=store1.getAll();

for (const element of elements) {
    console.log(element);
}
