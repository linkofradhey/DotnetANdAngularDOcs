"use strict";
//Normal Function
function calculateSalary(basicSalary, bonus) {
    return basicSalary + (bonus || 0);
}
console.log(calculateSalary(200000));
console.log(calculateSalary(200000, 5000));
//Arrow Function
const greet = (name) => {
    return `Hello ${name}`;
};
console.log(greet("Scott"));
