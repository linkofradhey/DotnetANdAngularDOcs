"use strict";
//generic function demo
function identity(value) {
    return value;
}
let result = identity("Hello");
console.log(result);
