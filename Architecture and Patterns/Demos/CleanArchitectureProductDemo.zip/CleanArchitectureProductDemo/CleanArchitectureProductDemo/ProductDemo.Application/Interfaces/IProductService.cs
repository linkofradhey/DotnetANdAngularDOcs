using ProductDemo.Domain.Entities;

namespace ProductDemo.Application.Interfaces;

// Application contract. The API and Infrastructure depend on this abstraction.
public interface IProductService
{
    Task<bool> AddProduct(Product newProduct);
    Task<bool> RemoveProduct(int id);
    Task<bool> UpdateProduct(Product updatedProduct);
    Task<Product?> SearchProductById(int id);
    Task<Product?> SearchProductByName(string name);
    Task<IEnumerable<Product>> GetAllProducts();
}
