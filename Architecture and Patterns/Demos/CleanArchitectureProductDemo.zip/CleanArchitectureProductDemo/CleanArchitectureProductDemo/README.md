# Clean Architecture – Product Web API (.NET 8)

This is a teaching-friendly refactor of the uploaded EMS Product implementation. It keeps the Product attributes, DTOs, AutoMapper mapping, service methods, soft-delete behavior, and controller-style endpoints while removing authentication, authorization, CORS, and API versioning as requested. It avoids primary constructors and other advanced syntax.

## Project responsibilities

* **ProductDemo.Domain** – `Product` entity and its data annotations. No EF Core or API dependency.
* **ProductDemo.Application** – `IProductService`, the use-case contract.
* **ProductDemo.Infrastructure** – EF Core `ECommContext` and `ProductService` implementation.
* **ProductDemo.API** – controller, DTOs, AutoMapper profile, configuration, and dependency registration.

Dependency direction: API → Application; API → Infrastructure (only at startup to register implementation); Infrastructure → Application + Domain; Application → Domain.

## Run on your machine

1. Open `ProductDemo.sln` in Visual Studio 2022.
2. Ensure the SQL Server LocalDB instance is installed, or update `ConnectionStrings:ECommCon` in `ProductDemo.API/appsettings.json` to your SQL Server/database.
3. Create the `Product` table in `ECommDB` with columns `ProductId` (int, primary key), `ProductName` (nvarchar(50)), `ProductCategory` (nvarchar(50)), `ListPrice` (float), and `IsDeleted` (bit). This demo intentionally does not include the original unrelated entities/migrations.
4. Set `ProductDemo.API` as the startup project and run. Swagger opens in Development.

Alternatively, from this directory:

```bash
dotnet restore ProductDemo.sln
dotnet build ProductDemo.sln
dotnet run --project ProductDemo.API
```

## Endpoints

* `GET /api/ProductInfo/GetAll`
* `GET /api/ProductInfo/GetById/100`
* `GET /api/ProductInfo/GetByName/Mouse`
* `POST /api/ProductInfo/AddProduct`
* `PUT /api/ProductInfo/UpdateProduct`
* `DELETE /api/ProductInfo/DeleteProduct/100`

Create/update JSON example:

```json
{
  "productId": 100,
  "productName": "Mouse",
  "productCategory": "Accessories",
  "listPrice": 499.99
}
```

## 

