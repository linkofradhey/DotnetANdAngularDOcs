using AutoMapper;
using ProductDemo.API.DTOs;
using ProductDemo.Domain.Entities;
namespace ProductDemo.API.Mapping;
public class ProductMappingProfile : Profile
{
    public ProductMappingProfile()
    {
        CreateMap<Product, ProductReadDto>();
        CreateMap<ProductCreateDto, Product>();
        CreateMap<ProductUpdateDto, Product>();
    }
}
