using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ProductDemo.API.DTOs;
using ProductDemo.Application.Interfaces;
using ProductDemo.Domain.Entities;

namespace ProductDemo.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ProductInfoController : ControllerBase
{
    private readonly IProductService _productService;
    private readonly IMapper _mapper;

    public ProductInfoController(IProductService productService, IMapper mapper)
    {
        _productService = productService;
        _mapper = mapper;
    }

    [HttpGet]
    [Route("GetAll")]
    [Produces("application/json")]
    public async Task<IActionResult> GetAllProducts()
    {
        var products = await _productService.GetAllProducts();
        if (products.Any())
        {
            var productDtos = _mapper.Map<IEnumerable<ProductReadDto>>(products);
            return Ok(productDtos);
        }
        return NotFound();
    }

    [HttpGet("GetById/{id:int:range(100,1000)}")]
    [Produces("application/json")]
    public async Task<IActionResult> GetProductById(int id)
    {
        var product = await _productService.SearchProductById(id);
        if (product == null) return NotFound();
        return Ok(_mapper.Map<ProductReadDto>(product));
    }

    [HttpGet("GetByName/{name:alpha:maxlength(50)}")]
    [Produces("application/json")]
    public async Task<IActionResult> GetProductByName(string name)
    {
        var product = await _productService.SearchProductByName(name);
        if (product == null) return NotFound();
        return Ok(_mapper.Map<ProductReadDto>(product));
    }

    [HttpPost("AddProduct")]
    [Produces("application/json")]
    [Consumes("application/json")]
    public async Task<IActionResult> PostNewProduct([FromBody] ProductCreateDto newProductDto)
    {
        Product product = _mapper.Map<Product>(newProductDto);
        var isSaved = await _productService.AddProduct(product);
        if (!isSaved) return BadRequest();
        var responseDto = _mapper.Map<ProductReadDto>(product);
        return Created(HttpContext.Request.Path, responseDto);
    }

    [HttpDelete("DeleteProduct/{id:int}")]
    public async Task<IActionResult> DeleteProduct(int id)
    {
        var isDeleted = await _productService.RemoveProduct(id);
        return isDeleted ? Ok() : NotFound();
    }

    [HttpPut("UpdateProduct")]
    [Consumes("application/json")]
    public async Task<IActionResult> UpdateProduct([FromBody] ProductUpdateDto updatedProductDto)
    {
        Product updatedProduct = _mapper.Map<Product>(updatedProductDto);
        var isUpdated = await _productService.UpdateProduct(updatedProduct);
        return isUpdated ? Accepted() : BadRequest();
    }
}
