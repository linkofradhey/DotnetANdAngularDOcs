using System.ComponentModel.DataAnnotations;
namespace ProductDemo.API.DTOs;
public class ProductUpdateDto
{
    [Required] public int ProductId { get; set; }
    [Required, StringLength(50, MinimumLength = 2)] public string? ProductName { get; set; }
    [Required, StringLength(50, MinimumLength = 2)] public string? ProductCategory { get; set; }
    [Range(0.01, double.MaxValue)] public double ListPrice { get; set; }
}
