using Microsoft.EntityFrameworkCore;
using ProductDemo.Application.Interfaces;
using ProductDemo.API.Mapping;
using ProductDemo.Infrastructure.Data;
using ProductDemo.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddAutoMapper(typeof(ProductMappingProfile));

// Infrastructure is selected at the composition root; API depends on the interface.
builder.Services.AddDbContext<ECommContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("ECommCon")));
builder.Services.AddScoped<IProductService, ProductService>();

var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseHttpsRedirection();
app.MapControllers();
app.Run();
