using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProductDemo.Domain.Entities;

[Table("Product")]
public class Product
{
    [Key]
    [DatabaseGenerated(DatabaseGeneratedOption.None)]
    [Column("ProductId")]
    [RegularExpression("^[0-9]*$")]
    public int ProductId { get; set; }

    [Column("ProductName")]
    [StringLength(50, MinimumLength = 2)]
    [Required]
    public string? ProductName { get; set; }

    [Column("ProductCategory")]
    [StringLength(50, MinimumLength = 2)]
    [Required]
    public string? ProductCategory { get; set; }

    [Column("ListPrice")]
    [Required]
    public double ListPrice { get; set; }

    [Column("IsDeleted")]
    [DefaultValue(false)]
    public bool IsDeleted { get; set; } = false;
}
