using Microsoft.EntityFrameworkCore;
using ProductDemo.Application.Interfaces;
using ProductDemo.Domain.Entities;
using ProductDemo.Infrastructure.Data;

namespace ProductDemo.Infrastructure.Repositories;

// Repository implementation: EF Core/database work stays in Infrastructure.
public class ProductService : IProductService
{
    private readonly ECommContext _dbContext;
    public ProductService(ECommContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<bool> AddProduct(Product newProduct)
    {
        if (newProduct == null) return false;
        _dbContext.Products.Add(newProduct);
        await _dbContext.SaveChangesAsync();
        return true;
    }

    public async Task<bool> RemoveProduct(int id)
    {
        var existingProduct = await _dbContext.Products.FirstOrDefaultAsync(p => p.ProductId == id);
        if (existingProduct == null) return false;
        // Soft delete: the global query filter hides this product afterwards.
        existingProduct.IsDeleted = true;
        await _dbContext.SaveChangesAsync();
        return true;
    }

    public async Task<bool> UpdateProduct(Product updatedProduct)
    {
        if (updatedProduct == null) return false;
        var existingProduct = await _dbContext.Products.FirstOrDefaultAsync(p => p.ProductId == updatedProduct.ProductId);
        if (existingProduct == null) return false;
        existingProduct.ProductName = updatedProduct.ProductName;
        existingProduct.ProductCategory = updatedProduct.ProductCategory;
        existingProduct.ListPrice = updatedProduct.ListPrice;
        await _dbContext.SaveChangesAsync();
        return true;
    }

    public async Task<IEnumerable<Product>> GetAllProducts()
    {
        return await _dbContext.Products.ToListAsync();
    }

    public async Task<Product?> SearchProductById(int id)
    {
        return await _dbContext.Products.FirstOrDefaultAsync(p => p.ProductId == id);
    }

    public async Task<Product?> SearchProductByName(string name)
    {
        return await _dbContext.Products.FirstOrDefaultAsync(p => p.ProductName == name);
    }
}
