using Microsoft.EntityFrameworkCore;
using ProductDemo.Domain.Entities;

namespace ProductDemo.Infrastructure.Data;

public class ECommContext : DbContext
{
    public ECommContext(DbContextOptions<ECommContext> options) : base(options) { }

    public DbSet<Product> Products { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Keep the same soft-delete behavior as the original project.
        modelBuilder.Entity<Product>().HasQueryFilter(p => !p.IsDeleted);
        base.OnModelCreating(modelBuilder);
    }
}
