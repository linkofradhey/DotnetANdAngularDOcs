﻿using DAL.DataAccess;
using DAL.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace ServiceLayer.Controllers
{
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    [EnableCors("AllowGetAndPost")]
    public class AdminUserController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private readonly IAdminInfoService<AdminInfo> _adminInfoService;
        public AdminUserController(IAdminInfoService<AdminInfo> adminInfoService, IConfiguration configuration)
        {
            this._adminInfoService=adminInfoService;
            this._configuration = configuration;
        }

        [HttpPost]
        [Route("ValidateAdmin")]
        [Consumes("application/json")]
        public async Task<IActionResult> ValidateAdminUser([FromBody] AdminInfo adminInfo)
        {
          var isValid=  await _adminInfoService.ValidateAdmin(adminInfo);
            if (isValid)
            {
              var token=  GenerateToken(adminInfo);
                return Ok(token);
            }
            else
            {
                return Unauthorized();//401
            }
        }

        [NonAction]
        public string GenerateToken(AdminInfo adminInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var signingCredential = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var issuer = _configuration["Jwt:Issuer"];
            var audience = _configuration["Jwt:Audience"];

            var claims = new[]
            {
                new Claim(ClaimTypes.Email,adminInfo.EmailId),
                new Claim(ClaimTypes.Role,adminInfo.Role)
            };

            var token = new JwtSecurityToken(issuer, audience, claims, expires: DateTime.Now.AddMinutes(30), signingCredentials: signingCredential);
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
