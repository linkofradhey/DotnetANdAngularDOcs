﻿using Asp.Versioning;
using AutoMapper;
using DAL.DataAccess;
using DAL.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Infrastructure;
using ServiceLayer.DTOs;

namespace ServiceLayer.Controllers
{
    [ApiVersion("2.0")]
    [Route("api/v{version:apiVersion}/[controller]")] //Route Template
    [ApiController]
    //[Authorize(Roles = "Admin")]
    public class ProductInfoController : ControllerBase
    {
        private readonly IProductService<Product> _productService;
        private readonly IMapper _mapper;
        public ProductInfoController(IProductService<Product> productService, IMapper mapper)
        {
            this._productService = productService;
            _mapper = mapper;
        }

       [HttpGet]
       [Route("/")]
       [Route("GetAll")]  //localhost:portno/api/ProductInfo/GetAll
       [Produces("application/json")]
       //[AllowAnonymous]
        public async Task<IActionResult> GetAllProducts()
        {
          var products= await _productService.GetAllProducts();
            if (products.ToList().Count>0)
            {
                var productDtos =
            _mapper.Map<IEnumerable<ProductReadDto>>(products);
                return Ok(productDtos); //200
            }
            else
            {
                throw new Exception("Products are Not Exist");
                return NotFound(); //404
            }

        }

        [HttpGet]
        [Route("GetById/{id:int:range(100,1000)}")] //localhost:portno/api/ProductInfo/GetById/id
        [Produces("application/json")]
        public async Task<IActionResult> GetProductById(int id)
        {
           var productById=await _productService.SearchProductById(id);
            if (productById != null)
            {
                var productDto = _mapper.Map<ProductReadDto>(productById);
                return Ok(productDto);//200
            }
            else
            {
                return NotFound();
            }
        }

        [HttpGet]
        [Route("GetByName/{name:alpha:maxlength(50)}")] //localhost:portno/api/ProductInfo/GetByName/name
        [Produces("application/json")]
        public async Task<IActionResult> GetProductByName(string name)
        {
            var productByName = await _productService.SearchProductByName(name);
            if (productByName != null)
            {
                var productDto = _mapper.Map<ProductReadDto>(productByName);
                return Ok(productDto);
            }
            else
            {
                return NotFound();
            }
        }


        [HttpPost]
        [Route("AddProduct")]
        [Produces("application/json")]
        [Consumes("application/json")]
        [Authorize(Roles ="Admin")]
        public async Task<IActionResult> PostNewProduct([FromBody] ProductCreateDto newProductDto) 
        {
            var product = _mapper.Map<Product>(newProductDto);
            var isSaved=  await _productService.AddProduct(product);
            if (isSaved)
            {
                var responseDto = _mapper.Map<ProductReadDto>(product);
                return Created(HttpContext.Request.Path, responseDto);//201
            }
            else
            {
                return BadRequest();//400
            }
        }

        [HttpDelete]
        [Route("DeleteProduct/{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
           var isDeleted= await _productService.RemoveProduct(id);
            if (isDeleted)
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }

        [HttpPut]
        [Route("UpdateProduct")]
        [Consumes("application/json")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> UpdateProduct([FromBody] ProductUpdateDto updatedProductDto)
        {
            // Convert DTO to entity
            var updatedProduct =
                _mapper.Map<Product>(updatedProductDto);

            var isUpdated=  await _productService.UpdateProduct(updatedProduct);
            if (isUpdated)
            {
                return Accepted();//202
            }
            else
            {
                return BadRequest();//400
            }
        }
    }
}
