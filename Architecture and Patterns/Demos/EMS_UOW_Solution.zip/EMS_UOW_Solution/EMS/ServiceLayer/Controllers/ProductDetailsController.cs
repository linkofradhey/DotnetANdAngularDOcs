﻿using DAL.DataAccess;
using DAL.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ServiceLayer.Controllers
{
    
    
    public class ProductDetailsController : ControllerBase
    {
        private readonly IProductService<Product> _productService;
        public ProductDetailsController(IProductService<Product> productService)
        {
            this._productService = productService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
          var products=  await _productService.GetAllProducts();
            if (products != null)
            {
                return Ok(products);
            }
            else
            {
                return NotFound();
            }
        }

        public async Task<IActionResult> GetProductById(int id)
        {
            var productById = await _productService.SearchProductById(id);
            if (productById != null)
            {
                return Ok(productById);
            }
            else
            {
                return NotFound();
            }
        }
    }
}
