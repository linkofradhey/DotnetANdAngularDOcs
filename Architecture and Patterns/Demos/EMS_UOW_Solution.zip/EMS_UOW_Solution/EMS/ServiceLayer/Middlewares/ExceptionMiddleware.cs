﻿using System.Text.Json;

namespace ServiceLayer.Middlewares
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private ILogger<ExceptionMiddleware> _logger;

        public ExceptionMiddleware(RequestDelegate next,ILogger<ExceptionMiddleware> logger)
        {
            this._next = next;
            this._logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                //Pass request to the next middleware
                await _next(context);
            }
            catch (Exception ex)
            {
                //Logging/writing error in console
                _logger.LogError(ex,"An Unexpected error occured");

                context.Response.StatusCode = StatusCodes.Status500InternalServerError;

                context.Response.ContentType = "application/json";

                var response = new
                {
                    StatusCode = 500,
                    Message = "An Unexpected error occured"
                };

                await context.Response.WriteAsync(JsonSerializer.Serialize(response));

            }
        }
    }
}
