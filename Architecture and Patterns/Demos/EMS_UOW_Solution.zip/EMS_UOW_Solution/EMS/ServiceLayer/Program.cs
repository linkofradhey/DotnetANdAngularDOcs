
using DAL.DataAccess;
using DAL.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi;
using ServiceLayer.Mapping;
using ServiceLayer.Middlewares;
using System.Text;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

//To Add/Configure Services and Register Dependencies
builder.Services.AddControllers(); //To convert asp.net core boilerplate to web api project

// Register AutoMapper and discover the mapping profile
builder.Services.AddAutoMapper(typeof(ProductMappingProfile));

//To Register Dependecies
// Unit of Work and services are scoped so they share one ECommContext per request.
builder.Services.AddScoped<ECommContext>();
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();
builder.Services.AddScoped<IProductService<Product>, ProductService>();
builder.Services.AddScoped<IAdminInfoService<AdminInfo>, AdminInfoService>();


//To configure Authentication using JWT Bearer Token
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
    };

});

//To configure swagger service
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Ecommerce API",
        Version = "v1",
        Description = "Its B2B API Documentation",
        TermsOfService = new Uri("https://www.kumaran.com/terms"),
        Contact = new Microsoft.OpenApi.Models.OpenApiContact
        {
            Name = "Shoaib",
            Email = "shoaib@kumaran.com",
            Url = new Uri("https://linkedin.com/abc")
        },
        License = new Microsoft.OpenApi.Models.OpenApiLicense
        {
            Name = "Kumaran Systems PVT LTD",
            Url = new Uri("https://kumaran.com/license")
        }
    });

    options.AddSecurityDefinition("Bearer",
        new OpenApiSecurityScheme
        {
            Name = "Authorization",
            Type = SecuritySchemeType.Http,
            Scheme = "bearer",
            BearerFormat = "JWT",
            In = ParameterLocation.Header,
            Description = "Enter your JWT token"
        });

    options.AddSecurityRequirement(
        new OpenApiSecurityRequirement
        {
            {
                new OpenApiSecurityScheme
                {
                    Reference = new OpenApiReference
                    {
                        Type = ReferenceType.SecurityScheme,
                        Id = "Bearer"
                    }
                },
                Array.Empty<string>()
            }
        });
});


//CORS policy
//How to implement default CORS policy?
builder.Services.AddCors(options =>
{   
    //default policy will be applied to all the api controllers by default
    options.AddDefaultPolicy(builder =>
    {
        //To grant access for any domain-for any header and method
        /// builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod();

        //To grant access for specific domain for specific method
        builder.WithOrigins("http://localhost:4200", "http://192.168.0.20").AllowAnyHeader().WithMethods("GET","PUT");
    });

    //How to implement Named policy?
    options.AddPolicy(name: "AllowGetAndPost", options =>
    {
        options.WithOrigins("http://localhost:4200", "http://192.168.0.20").AllowAnyHeader().WithMethods("GET","POST");
    });
});

//Api Versioning
builder.Services.AddApiVersioning(options =>
{
    //To configure default api versioning
    options.DefaultApiVersion = new Asp.Versioning.ApiVersion(1,0); //1.0
    options.AssumeDefaultVersionWhenUnspecified = true;
    options.ReportApiVersions = true;
}).AddMvc();

var app = builder.Build();
if (builder.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
app.UseRouting(); //To enable routing mechanism

app.UseCors();//To Add default Cors policy Middleware
app.UseCors("AllowGetAndPost");//To Add named Cors policy Middleware

app.UseSwagger();//To add swagger middleware
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json","My Ecommerce API");
});

//Register/Add custom exception middleware
app.UseMiddleware<ExceptionMiddleware>();

app.UseAuthentication();
app.UseAuthorization();

app.UseEndpoints(endpoint =>
{
    endpoint.MapControllers(); //To enable Attribute based routing 

    //endpoint.MapControllerRoute(name:"default",pattern:"api/{controller}/{action}/{id?}"); //To enable convention based routing
});


app.Run();
