﻿namespace ServiceLayer.DTOs
{
    public class ProductReadDto
    {
        public int ProductId { get; set; }

        public string? ProductName { get; set; }

        public string? ProductCategory { get; set; }

        public double ListPrice { get; set; }
    }
}
