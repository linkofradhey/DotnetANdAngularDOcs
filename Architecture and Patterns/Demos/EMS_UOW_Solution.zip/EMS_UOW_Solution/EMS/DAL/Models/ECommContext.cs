﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models
{
    public class ECommContext:DbContext
    {
        //To declare prop. of type DbSet<TEntity>
        public DbSet<AdminInfo> AdminInfos { get; set; }
        public DbSet<CustomerInfo> CustomerInfos { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
       

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //To configure a connection string
            if(!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(DatabaseHelper.GetConnectionString());
            }
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //To Configure entities/domain class or add seed data using fluent api code

            //To add seed data

            modelBuilder.Entity<AdminInfo>().HasData(
                new AdminInfo { EmailId="admin@gmail.com",Password="admin123",Role="Admin"}
                );

            //To map database view with entity class
            //modelBuilder.Entity<Select_Order_With_Product>().HasNoKey().ToView("Select_OrderDetails_With_Product");

            //To declare shadow property
            //modelBuilder.Entity<Product>().Property<DateTime>("CreatedDate").HasDefaultValueSql("GETDATE()");

            //To Set Global Query Filter
            modelBuilder.Entity<Product>().HasQueryFilter(p=>!p.IsDeleted);

            base.OnModelCreating(modelBuilder);
        }
    }
}
