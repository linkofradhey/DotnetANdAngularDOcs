﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models
{
    [Table("Order")]
    public class Order
    {
        [Key]
        [Column("OrderId")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [RegularExpression(pattern: "^[0-9]*$")]
        public int OrderId { get; set; }

        [Column("OrderDate")]
        [DataType(DataType.Date)]
        [Required]
        public DateTime OrderDate { get; set; }

        [Column("OrderAmount")]
        [Required]
        public double OrderAmount { get; set; }

        //Foreign Key
        public string EmailId { get; set; } //customer emailid
        public int ProductId { get; set; }

        //Navigation Property to connect with CustomerInfo
        public virtual CustomerInfo CustInfoes { get; set; }

        public virtual Product ProductDetail { get; set; }

        //Many-Many relationship between product and order
        //public virtual ICollection< Product> Products { get; set; }
    }
}
