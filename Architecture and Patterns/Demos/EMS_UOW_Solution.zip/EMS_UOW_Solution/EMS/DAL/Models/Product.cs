﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models
{
    [Table("Product")]

    public class Product
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [Column("ProductId")]
        [RegularExpression(pattern:"^[0-9]*$")]
       
        public int ProductId { get; set; }

        [Column("ProductName")]
        [StringLength(maximumLength:50,MinimumLength =2)]
        [Required]
      
        public string? ProductName { get; set; }

        [Column("ProductCategory")]
        [StringLength(maximumLength:50,MinimumLength =2)]
        [Required]
       
        public string? ProductCategory { get; set; }

        [Column("ListPrice")]
        [Required]
        
        public double ListPrice { get; set; }

        [Column("IsDeleted")]
        [DefaultValue(false)]
        
        public bool IsDeleted { get; set; } = false;

        //Navigation Property to connect with Order
        public virtual ICollection<Order> Orders {  get; set; }
    }
}
