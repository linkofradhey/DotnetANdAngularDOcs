﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models
{
    public static class DatabaseHelper
    {
        public static string GetConnectionString()
        {
            var builder =new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).
                AddJsonFile("appSettings.json",optional:true,reloadOnChange:true);
          var connectionString=  builder.Build().GetConnectionString("ECommCon");
            return connectionString;
            
        }
    }
}
