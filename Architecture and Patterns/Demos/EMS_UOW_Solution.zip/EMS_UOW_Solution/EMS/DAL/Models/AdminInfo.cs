﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models
{
    [Table("AdminInfo")]
    public class AdminInfo
    {
        [Key]
        [Column("EmailId")]
        [StringLength(maximumLength:100,MinimumLength =10)]
        [DataType(DataType.EmailAddress)]
        public string? EmailId { get; set; }

        [Column("Password")]
        [DataType(DataType.Password)]
        [StringLength(maximumLength:20,MinimumLength =6)]
        [Required]
        public string? Password { get; set; }

        [Column("Role")]
        [StringLength(maximumLength:10)]
        [DefaultValue("Admin")]
        public string? Role { get; set; }
    }
}
