﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Globalization;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace DAL.Models
{
    [Table("CustomerInfo")]
    public class CustomerInfo
    {
        [Key]
        [Column("EmailId")]
        [StringLength(maximumLength:100,MinimumLength =10)]
        public string? EmailId { get; set; }

        [Column("Password")]
        [StringLength(maximumLength:20,MinimumLength =6)]
        public string?  Password { get; set; }

        [Column("Role")]
        [DefaultValue("Customer")]
        [StringLength(maximumLength:10)]
        public string? Role { get; set; }
 

        //Navigation Property to Connect with Order 
        public virtual ICollection<Order> Orders { get; set; }
    }
}
