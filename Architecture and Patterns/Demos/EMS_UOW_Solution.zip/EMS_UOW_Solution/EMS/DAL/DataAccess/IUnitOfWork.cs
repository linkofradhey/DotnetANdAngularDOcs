using DAL.Models;

namespace DAL.DataAccess
{
    public interface IUnitOfWork : IDisposable
    {
        ECommContext Context { get; }
        Task<int> SaveChangesAsync();
    }
}
