using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL.DataAccess
{
    public class AdminInfoService : IAdminInfoService<AdminInfo>
    {
        private readonly IUnitOfWork _unitOfWork;

        public AdminInfoService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> ValidateAdmin(AdminInfo entity)
        {
            if (entity == null)
            {
                return false;
            }

            return await _unitOfWork.Context.AdminInfos.AnyAsync(admin =>
                admin.EmailId == entity.EmailId &&
                admin.Password == entity.Password &&
                admin.Role == "Admin");
        }
    }
}
