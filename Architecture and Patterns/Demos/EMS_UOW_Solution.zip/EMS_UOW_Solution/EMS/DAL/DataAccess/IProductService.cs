﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.DataAccess
{
    public interface IProductService<T>
    {
       Task <bool> AddProduct(T newProduct);
       Task <bool> RemoveProduct(int id);
       Task <bool> UpdateProduct(T updatedProduct);
       Task<T> SearchProductById(int id);
       Task <T> SearchProductByName(string name);
       Task< IEnumerable<T>> GetAllProducts();
    }
}
