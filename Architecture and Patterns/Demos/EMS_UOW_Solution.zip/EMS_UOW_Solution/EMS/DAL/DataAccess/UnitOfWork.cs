using DAL.Models;

namespace DAL.DataAccess
{
    // One UnitOfWork instance shares one EF Core DbContext across participating services.
    public class UnitOfWork : IUnitOfWork
    {
        private readonly ECommContext _context;

        public UnitOfWork(ECommContext context)
        {
            _context = context;
        }

        public ECommContext Context
        {
            get { return _context; }
        }

        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
