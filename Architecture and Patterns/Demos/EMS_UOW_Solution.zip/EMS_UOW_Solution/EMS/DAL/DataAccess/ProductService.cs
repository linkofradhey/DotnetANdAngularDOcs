using DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace DAL.DataAccess
{
    public class ProductService : IProductService<Product>
    {
        private readonly IUnitOfWork _unitOfWork;

        public ProductService(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> AddProduct(Product newProduct)
        {
            if (newProduct == null)
            {
                return false;
            }

            _unitOfWork.Context.Products.Add(newProduct);
            await _unitOfWork.SaveChangesAsync();
            return true;
        }

        public async Task<bool> RemoveProduct(int id)
        {
            var existingProduct = await _unitOfWork.Context.Products
                .FirstOrDefaultAsync(pro => pro.ProductId == id);

            if (existingProduct == null)
            {
                return false;
            }

            // Preserve the existing soft-delete behavior.
            existingProduct.IsDeleted = true;
            await _unitOfWork.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateProduct(Product updatedProduct)
        {
            if (updatedProduct == null)
            {
                return false;
            }

            var existingProduct = await _unitOfWork.Context.Products
                .FirstOrDefaultAsync(pro => pro.ProductId == updatedProduct.ProductId);

            if (existingProduct == null)
            {
                return false;
            }

            existingProduct.ProductName = updatedProduct.ProductName;
            existingProduct.ProductCategory = updatedProduct.ProductCategory;
            existingProduct.ListPrice = updatedProduct.ListPrice;

            await _unitOfWork.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<Product>> GetAllProducts()
        {
            return await _unitOfWork.Context.Products.ToListAsync();
        }

        public async Task<Product> SearchProductById(int id)
        {
            return await _unitOfWork.Context.Products
                .FirstOrDefaultAsync(pro => pro.ProductId == id);
        }

        public async Task<Product> SearchProductByName(string name)
        {
            return await _unitOfWork.Context.Products
                .FirstOrDefaultAsync(pro => pro.ProductName == name);
        }
    }
}
